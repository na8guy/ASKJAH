const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { authenticateToken } = require('../middleware/auth');
const User = require('../models/User');
const Subscription = require('../models/Subscription');
const { logAudit } = require('../utils/auditLogger');

const router = express.Router();

// Pricing configuration
const PRICING = {
  PRO: {
    priceId: process.env.STRIPE_PRO_PRICE_ID || 'price_pro_monthly',
    amount: 2900, // £29/month
    interval: 'month'
  },
  ACCELERATOR: {
    priceId: process.env.STRIPE_ACCELERATOR_PRICE_ID || 'price_accelerator_onetime',
    amount: 49700, // £497 one-time
    interval: 'one_time'
  }
};

// Create Checkout Session
router.post('/create-checkout', authenticateToken, async (req, res) => {
  try {
    const { planType } = req.body;
    const user = await User.findById(req.user.id);

    if (!['PRO', 'ACCELERATOR'].includes(planType)) {
      return res.status(400).json({ error: 'Invalid plan type' });
    }

    const pricing = PRICING[planType];
    
    // Get or create Stripe customer
    let customerId;
    const existingSubscription = await Subscription.findByUserId(user.id);
    
    if (existingSubscription?.stripe_customer_id) {
      customerId = existingSubscription.stripe_customer_id;
    } else {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: {
          userId: user.id,
          firstName: user.first_name,
          lastName: user.last_name
        }
      });
      customerId = customer.id;
    }

    // Create checkout session
    const sessionConfig = {
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price: pricing.priceId,
          quantity: 1,
        },
      ],
      mode: planType === 'ACCELERATOR' ? 'payment' : 'subscription',
      success_url: `${process.env.APP_URL}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.APP_URL}/pricing`,
      metadata: {
        userId: user.id,
        planType: planType
      }
    };

    const session = await stripe.checkout.sessions.create(sessionConfig);

    await logAudit({
      userId: user.id,
      action: 'CHECKOUT_CREATED',
      entityType: 'subscription',
      changes: { planType, sessionId: session.id }
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Checkout error:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Create Customer Portal Session
router.post('/create-portal-session', authenticateToken, async (req, res) => {
  try {
    const subscription = await Subscription.findByUserId(req.user.id);
    
    if (!subscription?.stripe_customer_id) {
      return res.status(404).json({ error: 'No subscription found' });
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: subscription.stripe_customer_id,
      return_url: `${process.env.APP_URL}/dashboard`,
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error('Portal error:', error);
    res.status(500).json({ error: 'Failed to create portal session' });
  }
});

// Stripe Webhook Handler
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
        await handleCheckoutCompleted(event.data.object);
        break;

      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await handleSubscriptionUpdate(event.data.object);
        break;

      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object);
        break;

      case 'invoice.payment_succeeded':
        await handlePaymentSucceeded(event.data.object);
        break;

      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object);
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Webhook handler error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Webhook Handlers
async function handleCheckoutCompleted(session) {
  const userId = session.metadata.userId;
  const planType = session.metadata.planType;
  const customerId = session.customer;

  // Update or create subscription
  const existingSubscription = await Subscription.findByUserId(userId);
  
  if (existingSubscription) {
    await Subscription.update(existingSubscription.id, {
      stripe_customer_id: customerId,
      stripe_subscription_id: session.subscription || null,
      plan_type: planType,
      status: 'active',
      current_period_start: new Date(),
      current_period_end: planType === 'ACCELERATOR' ? null : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    });
  } else {
    await Subscription.create({
      userId,
      stripeCustomerId: customerId,
      stripeSubscriptionId: session.subscription || null,
      planType,
      status: 'active'
    });
  }

  // Update user role
  await User.updateRole(userId, planType);

  await logAudit({
    userId,
    action: 'PAYMENT_SUCCESS',
    entityType: 'subscription',
    changes: { planType, customerId }
  });
}

async function handleSubscriptionUpdate(subscription) {
  const customerId = subscription.customer;
  const dbSubscription = await Subscription.findByStripeCustomerId(customerId);
  
  if (dbSubscription) {
    await Subscription.update(dbSubscription.id, {
      status: subscription.status,
      current_period_start: new Date(subscription.current_period_start * 1000),
      current_period_end: new Date(subscription.current_period_end * 1000),
      cancel_at_period_end: subscription.cancel_at_period_end
    });
  }
}

async function handleSubscriptionDeleted(subscription) {
  const customerId = subscription.customer;
  const dbSubscription = await Subscription.findByStripeCustomerId(customerId);
  
  if (dbSubscription) {
    await Subscription.update(dbSubscription.id, {
      status: 'canceled',
      canceled_at: new Date()
    });

    // Downgrade user to FREE
    await User.updateRole(dbSubscription.user_id, 'FREE');
  }
}

async function handlePaymentSucceeded(invoice) {
  const customerId = invoice.customer;
  const dbSubscription = await Subscription.findByStripeCustomerId(customerId);
  
  if (dbSubscription) {
    await logAudit({
      userId: dbSubscription.user_id,
      action: 'PAYMENT_SUCCEEDED',
      entityType: 'subscription',
      changes: { invoiceId: invoice.id, amount: invoice.amount_paid }
    });
  }
}

async function handlePaymentFailed(invoice) {
  const customerId = invoice.customer;
  const dbSubscription = await Subscription.findByStripeCustomerId(customerId);
  
  if (dbSubscription) {
    await Subscription.update(dbSubscription.id, {
      status: 'past_due'
    });

    await logAudit({
      userId: dbSubscription.user_id,
      action: 'PAYMENT_FAILED',
      entityType: 'subscription',
      changes: { invoiceId: invoice.id },
      status: 'failed'
    });
  }
}

module.exports = router;
