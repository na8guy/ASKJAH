const { query } = require('../config/database');

async function logAudit({
  userId,
  action,
  entityType,
  entityId = null,
  changes = null,
  ipAddress = null,
  userAgent = null,
  status = 'success',
  errorMessage = null
}) {
  try {
    await query(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, changes, ip_address, user_agent, status, error_message)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [userId, action, entityType, entityId, JSON.stringify(changes), ipAddress, userAgent, status, errorMessage]
    );
  } catch (error) {
    console.error('Audit log error:', error);
  }
}

module.exports = { logAudit };
