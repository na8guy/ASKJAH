require('dotenv').config();
const cron = require('node-cron');
const { query } = require('./config/database');
const { sendEmail } = require('./utils/emailService');

console.log('⏰ Cron service starting...');

// Helper to create notification
async function createNotification(userId, type, title, message, link = null, priority = 'normal') {
  await query(
    `INSERT INTO notifications (user_id, notification_type, title, message, link, priority)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [userId, type, title, message, link, priority]
  );
}

// Weekly Savings Consistency Check (Every Monday at 9 AM)
cron.schedule('0 9 * * 1', async () => {
  console.log('Running weekly savings check...');

  try {
    const users = await query(`
      SELECT u.id, u.email, u.first_name, fp.monthly_savings_target, fp.current_savings
      FROM users u
      JOIN financial_profiles fp ON u.id = fp.user_id
      WHERE u.role IN ('PRO', 'ACCELERATOR') AND u.is_active = true
    `);

    for (const user of users.rows) {
      await createNotification(
        user.id,
        'savings_reminder',
        'Weekly Savings Check-In',
        `Have you hit your £${user.monthly_savings_target} savings target this month?`,
        '/dashboard/savings',
        'normal'
      );

      // Send email if enabled
      if (process.env.ENABLE_EMAIL_NOTIFICATIONS === 'true') {
        await sendEmail(
          user.email,
          'Weekly Savings Check-In',
          `Hi ${user.first_name},\n\nJust checking in on your savings progress!\n\nTarget: £${user.monthly_savings_target}/month`
        );
      }
    }

    console.log(`✓ Sent savings reminders to ${users.rows.length} users`);
  } catch (error) {
    console.error('Savings check failed:', error);
  }
});

// Monthly Capital Blueprint Review (1st of every month at 10 AM)
cron.schedule('0 10 1 * *', async () => {
  console.log('Running monthly blueprint review reminder...');

  try {
    const users = await query(`
      SELECT DISTINCT u.id, u.email, u.first_name
      FROM users u
      JOIN capital_blueprints cb ON u.id = cb.user_id
      WHERE u.role IN ('PRO', 'ACCELERATOR') 
        AND u.is_active = true
        AND cb.status = 'active'
        AND cb.created_at < NOW() - INTERVAL '30 days'
    `);

    for (const user of users.rows) {
      await createNotification(
        user.id,
        'blueprint_review',
        'Monthly Blueprint Review',
        'Time to review and update your capital blueprint!',
        '/dashboard/blueprint',
        'high'
      );
    }

    console.log(`✓ Sent blueprint reminders to ${users.rows.length} users`);
  } catch (error) {
    console.error('Blueprint reminder failed:', error);
  }
});

// JV Team Inactivity Alert (Every day at 2 PM)
cron.schedule('0 14 * * *', async () => {
  console.log('Checking for inactive JV teams...');

  try {
    const inactiveTeams = await query(`
      SELECT t.id, t.name, m.user_id, u.email, u.first_name
      FROM jv_teams t
      JOIN jv_team_members m ON t.id = m.team_id
      JOIN users u ON m.user_id = u.id
      WHERE t.status = 'active'
        AND t.updated_at < NOW() - INTERVAL '14 days'
        AND m.status = 'active'
    `);

    for (const team of inactiveTeams.rows) {
      await createNotification(
        team.user_id,
        'jv_inactivity',
        'JV Team Inactive',
        `Your team "${team.name}" has been inactive for 14 days. Time to re-engage!`,
        `/jv/team/${team.id}`,
        'high'
      );
    }

    console.log(`✓ Sent inactivity alerts to ${inactiveTeams.rows.length} team members`);
  } catch (error) {
    console.error('JV inactivity check failed:', error);
  }
});

// Credit Score Reminder (Every 3 months on the 1st at 11 AM)
cron.schedule('0 11 1 */3 *', async () => {
  console.log('Running credit optimization reminder...');

  try {
    const users = await query(`
      SELECT u.id, u.email, u.first_name, fp.credit_score
      FROM users u
      JOIN financial_profiles fp ON u.id = fp.user_id
      WHERE u.role IN ('PRO', 'ACCELERATOR') AND u.is_active = true
    `);

    for (const user of users.rows) {
      await createNotification(
        user.id,
        'credit_reminder',
        'Quarterly Credit Check',
        'Check your credit score and review optimization opportunities',
        '/dashboard/credit',
        'normal'
      );
    }

    console.log(`✓ Sent credit reminders to ${users.rows.length} users`);
  } catch (error) {
    console.error('Credit reminder failed:', error);
  }
});

// Income Progress Check (Every 2 weeks on Monday at 9 AM)
cron.schedule('0 9 * * 1', async () => {
  const weekNumber = Math.floor(Date.now() / (1000 * 60 * 60 * 24 * 7));
  if (weekNumber % 2 !== 0) return; // Only run every other week

  console.log('Running income progress check...');

  try {
    const users = await query(`
      SELECT DISTINCT u.id, u.email, u.first_name
      FROM users u
      JOIN income_plans ip ON u.id = ip.user_id
      WHERE u.role IN ('PRO', 'ACCELERATOR')
        AND u.is_active = true
        AND ip.status IN ('active', 'in_progress')
    `);

    for (const user of users.rows) {
      await createNotification(
        user.id,
        'income_check',
        'Income Acceleration Check-In',
        'How are your income-boosting strategies performing?',
        '/dashboard/income',
        'normal'
      );
    }

    console.log(`✓ Sent income check-ins to ${users.rows.length} users`);
  } catch (error) {
    console.error('Income check failed:', error);
  }
});

// Subscription Renewal Reminder (Daily at 8 AM)
cron.schedule('0 8 * * *', async () => {
  console.log('Checking subscription renewals...');

  try {
    const expiringSubscriptions = await query(`
      SELECT u.id, u.email, u.first_name, s.current_period_end, s.plan_type
      FROM users u
      JOIN subscriptions s ON u.id = s.user_id
      WHERE s.status = 'active'
        AND s.current_period_end > NOW()
        AND s.current_period_end < NOW() + INTERVAL '7 days'
    `);

    for (const sub of expiringSubscriptions.rows) {
      await createNotification(
        sub.id,
        'subscription_renewal',
        'Subscription Renewal Coming Up',
        `Your ${sub.plan_type} subscription renews soon`,
        '/account/billing',
        'normal'
      );
    }

    console.log(`✓ Sent renewal reminders to ${expiringSubscriptions.rows.length} users`);
  } catch (error) {
    console.error('Subscription check failed:', error);
  }
});

console.log('✓ Cron jobs scheduled:');
console.log('  - Weekly savings check (Mon 9am)');
console.log('  - Monthly blueprint review (1st 10am)');
console.log('  - Daily JV inactivity check (2pm)');
console.log('  - Quarterly credit reminder (1st 11am)');
console.log('  - Bi-weekly income check (Mon 9am)');
console.log('  - Daily subscription renewal check (8am)');

// Keep process running
process.stdin.resume();

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Cron service shutting down...');
  process.exit(0);
});
