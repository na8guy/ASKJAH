# Incipio Launchpad - Deployment Guide

## Prerequisites

- Node.js 18+
- PostgreSQL 14+
- Redis 6+
- Stripe Account
- Claude API Key (Anthropic)
- Render Account (or alternative hosting)

## Local Development Setup

### 1. Install Dependencies

```bash
# Install backend dependencies
npm install

# Install frontend dependencies
cd frontend && npm install
```

### 2. Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Required environment variables:
- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Strong secret for JWT tokens
- `STRIPE_SECRET_KEY` - Stripe secret key
- `STRIPE_WEBHOOK_SECRET` - Stripe webhook signing secret
- `CLAUDE_API_KEY` - Claude API key
- `REDIS_URL` - Redis connection string
- `SMTP_*` - Email configuration

### 3. Database Setup

```bash
# Run migrations
npm run migrate
```

### 4. Run Development Servers

```bash
# Terminal 1: API Server
npm run server

# Terminal 2: Worker
npm run worker

# Terminal 3: Cron Service
npm run cron

# Terminal 4: Frontend
npm run client

# Or run all at once:
npm run dev
```

## Render Deployment

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
```

### 2. Connect to Render

1. Sign in to [Render](https://render.com)
2. Click "New" → "Blueprint"
3. Connect your GitHub repository
4. Render will detect `render.yaml` and create all services

### 3. Configure Environment Variables

In Render Dashboard, set these environment variables for each service:

**Web Service (API):**
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `CLAUDE_API_KEY`
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`
- `EMAIL_FROM`

**Worker Service:**
- `CLAUDE_API_KEY`

**Cron Service:**
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`
- `EMAIL_FROM`

### 4. Configure Stripe Webhooks

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://your-api.onrender.com/api/payments/webhook`
3. Select events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
4. Copy webhook signing secret to `STRIPE_WEBHOOK_SECRET`

### 5. Create Stripe Products

Create products in Stripe Dashboard:

1. **PRO Plan**
   - Name: "Incipio PRO"
   - Price: £29/month
   - Copy Price ID to `STRIPE_PRO_PRICE_ID`

2. **ACCELERATOR Plan**
   - Name: "Incipio Accelerator"
   - Price: £497 one-time
   - Copy Price ID to `STRIPE_ACCELERATOR_PRICE_ID`

### 6. Deploy

Render will automatically deploy when you push to main:

```bash
git push origin main
```

### 7. Post-Deployment

1. Verify all services are running in Render Dashboard
2. Test authentication flow
3. Test Stripe checkout
4. Verify webhooks are working
5. Test AI endpoints
6. Check worker jobs are processing
7. Verify cron jobs execute

## Manual Deployment (Alternative Platforms)

### Docker Deployment

```dockerfile
# Dockerfile (create this file)
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

# Build frontend
WORKDIR /app/frontend
RUN npm ci && npm run build

WORKDIR /app

EXPOSE 5000

CMD ["npm", "start"]
```

Build and run:

```bash
docker build -t incipio-launchpad .
docker run -p 5000:5000 --env-file .env incipio-launchpad
```

### AWS/DigitalOcean/etc.

1. Provision Ubuntu 22.04 server
2. Install Node.js, PostgreSQL, Redis
3. Clone repository
4. Install dependencies
5. Configure environment variables
6. Run migrations
7. Use PM2 for process management:

```bash
npm install -g pm2

# Start services
pm2 start backend/server.js --name api
pm2 start backend/worker.js --name worker
pm2 start backend/cron.js --name cron

# Save configuration
pm2 save
pm2 startup
```

8. Configure nginx reverse proxy
9. Set up SSL with Let's Encrypt

## Monitoring & Maintenance

### Health Checks

- API: `https://your-api.onrender.com/health`
- Check logs in Render Dashboard
- Monitor database connections
- Monitor Redis queue depth

### Database Backups

Render PostgreSQL includes automatic backups. For manual backup:

```bash
pg_dump $DATABASE_URL > backup.sql
```

### Scaling

Adjust service plans in Render Dashboard based on usage:
- Start with Standard plans
- Scale up for >1000 concurrent users
- Add read replicas for database if needed

### Updates

```bash
git pull origin main
npm install
npm run migrate  # If new migrations
pm2 restart all  # If using PM2
```

## Troubleshooting

### API not responding
- Check service logs in Render
- Verify environment variables are set
- Check database connection

### Stripe webhooks failing
- Verify webhook secret matches
- Check endpoint URL is correct
- Review webhook logs in Stripe Dashboard

### Worker jobs not processing
- Check Redis connection
- Verify worker service is running
- Check job queue in Redis

### Claude API errors
- Verify API key is correct
- Check rate limits
- Review error logs

## Security Checklist

- [ ] All environment variables set securely
- [ ] Database uses strong password
- [ ] JWT_SECRET is cryptographically random
- [ ] CORS configured correctly
- [ ] Rate limiting enabled
- [ ] Helmet security headers active
- [ ] Input validation on all endpoints
- [ ] Audit logging enabled
- [ ] SSL/TLS enabled (automatic on Render)
- [ ] Regular dependency updates

## Support

For issues, check:
1. Service logs
2. Database connectivity
3. Environment variable configuration
4. API endpoint responses
5. Stripe webhook logs
