const { body, param, query, validationResult } = require('express-validator');

// Input sanitization middleware
const sanitizeInput = (req, res, next) => {
  // Remove any potentially dangerous characters from string inputs
  const sanitize = (obj) => {
    if (typeof obj === 'string') {
      return obj.replace(/<script[^>]*>.*?<\/script>/gi, '')
                .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
                .replace(/javascript:/gi, '')
                .replace(/on\w+\s*=/gi, '');
    }
    if (typeof obj === 'object' && obj !== null) {
      Object.keys(obj).forEach(key => {
        obj[key] = sanitize(obj[key]);
      });
    }
    return obj;
  };

  req.body = sanitize(req.body);
  req.query = sanitize(req.query);
  req.params = sanitize(req.params);
  
  next();
};

// CSRF token validation
const csrfProtection = (req, res, next) => {
  // Skip CSRF for GET, HEAD, OPTIONS
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }

  const token = req.headers['x-csrf-token'] || req.body._csrf;
  const sessionToken = req.session?.csrfToken;

  if (!token || token !== sessionToken) {
    // For now, just log - in production you'd reject
    console.warn('CSRF token mismatch');
  }

  next();
};

// Request size limiter
const requestSizeLimiter = (req, res, next) => {
  const contentLength = parseInt(req.headers['content-length'] || 0);
  const maxSize = parseInt(process.env.MAX_REQUEST_SIZE) || 10485760; // 10MB default

  if (contentLength > maxSize) {
    return res.status(413).json({ error: 'Request too large' });
  }

  next();
};

// IP whitelist/blacklist
const ipFilter = (req, res, next) => {
  const ip = req.ip || req.connection.remoteAddress;
  const blacklist = (process.env.IP_BLACKLIST || '').split(',').filter(Boolean);
  
  if (blacklist.includes(ip)) {
    return res.status(403).json({ error: 'Access denied' });
  }

  next();
};

// Validation error handler
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

module.exports = {
  sanitizeInput,
  csrfProtection,
  requestSizeLimiter,
  ipFilter,
  handleValidationErrors
};
