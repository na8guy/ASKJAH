const { query } = require('../config/database');

class Subscription {
  static async create({ userId, stripeCustomerId, stripeSubscriptionId, planType, status }) {
    const result = await query(
      `INSERT INTO subscriptions (user_id, stripe_customer_id, stripe_subscription_id, plan_type, status)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [userId, stripeCustomerId, stripeSubscriptionId, planType, status]
    );
    return result.rows[0];
  }

  static async findByUserId(userId) {
    const result = await query(
      'SELECT * FROM subscriptions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1',
      [userId]
    );
    return result.rows[0];
  }

  static async findByStripeCustomerId(stripeCustomerId) {
    const result = await query(
      'SELECT * FROM subscriptions WHERE stripe_customer_id = $1',
      [stripeCustomerId]
    );
    return result.rows[0];
  }

  static async update(id, data) {
    const fields = [];
    const values = [];
    let paramCount = 1;

    Object.keys(data).forEach(key => {
      fields.push(`${key} = $${paramCount}`);
      values.push(data[key]);
      paramCount++;
    });

    values.push(id);
    const result = await query(
      `UPDATE subscriptions SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`,
      values
    );
    return result.rows[0];
  }
}

module.exports = Subscription;
