import React from 'react';
import Layout from '../components/Layout';

const Deals = () => {
  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px' }}>
          Deals
        </h1>
        <div className="card">
          <p style={{ color: 'var(--text-secondary)' }}>
            Deal tracking and analysis coming soon...
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Deals;
