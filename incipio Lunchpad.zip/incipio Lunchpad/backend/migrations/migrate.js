const fs = require('fs');
const path = require('path');
const { pool } = require('../config/database');

async function runMigrations() {
  const client = await pool.connect();
  
  try {
    console.log('Starting database migrations...');
    
    // Create migrations table if it doesn't exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id SERIAL PRIMARY KEY,
        migration_name VARCHAR(255) UNIQUE NOT NULL,
        executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Get list of executed migrations
    const { rows: executedMigrations } = await client.query(
      'SELECT migration_name FROM schema_migrations ORDER BY id'
    );
    const executedSet = new Set(executedMigrations.map(m => m.migration_name));
    
    // Get all migration files
    const migrationsDir = __dirname;
    const files = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql'))
      .sort();
    
    // Execute pending migrations
    for (const file of files) {
      if (executedSet.has(file)) {
        console.log(`✓ Skipping ${file} (already executed)`);
        continue;
      }
      
      console.log(`▶ Executing ${file}...`);
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
      
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO schema_migrations (migration_name) VALUES ($1)',
          [file]
        );
        await client.query('COMMIT');
        console.log(`✓ Successfully executed ${file}`);
      } catch (error) {
        await client.query('ROLLBACK');
        console.error(`✗ Failed to execute ${file}:`, error.message);
        throw error;
      }
    }
    
    console.log('✓ All migrations completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

runMigrations();
