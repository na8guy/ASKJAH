import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import toast from 'react-hot-toast';
import { TrendingUp, AlertCircle } from 'lucide-react';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const CapitalBlueprint = () => {
  const [profile, setProfile] = useState(null);
  const [blueprint, setBlueprint] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await axios.get(`${API_URL}/financial/profile`);
      setProfile(response.data);
    } catch (error) {
      console.error('Failed to fetch profile');
    }
  };

  const generateBlueprint = async () => {
    if (!profile) {
      toast.error('Please complete your financial profile first');
      return;
    }

    setLoading(true);

    try {
      const response = await axios.post(`${API_URL}/ai/capital-blueprint`, {
        financialData: {
          annualIncome: profile.annual_income,
          monthlyExpenses: profile.monthly_expenses,
          currentSavings: profile.current_savings,
          targetDeposit: profile.target_deposit,
          debtTotal: profile.debt_total,
          creditScore: profile.credit_score
        }
      });

      setBlueprint(response.data);
      toast.success('Blueprint generated successfully!');
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to generate blueprint');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h1 style={{ fontSize: '32px', fontWeight: 'bold' }}>
            Capital Blueprint
          </h1>
          <button 
            onClick={generateBlueprint} 
            className="btn btn-primary"
            disabled={loading || !profile}
          >
            {loading ? 'Generating...' : 'Generate New Blueprint'}
          </button>
        </div>

        {!profile && (
          <div className="card" style={{ background: 'rgba(255, 184, 0, 0.1)', border: '1px solid var(--warning)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <AlertCircle size={24} style={{ color: 'var(--warning)' }} />
              <p>Please complete your financial profile before generating a blueprint.</p>
            </div>
          </div>
        )}

        {blueprint && (
          <div style={{ display: 'grid', gap: '24px' }}>
            <div className="card">
              <h2 className="card-title">Summary</h2>
              <p style={{ color: 'var(--text-secondary)', marginTop: '12px' }}>
                {blueprint.summary}
              </p>
            </div>

            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-label">Current Savings</div>
                <div className="stat-value">£{blueprint.metrics?.currentSavings?.toLocaleString()}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Target Deposit</div>
                <div className="stat-value">£{blueprint.metrics?.targetDeposit?.toLocaleString()}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Monthly Required</div>
                <div className="stat-value">£{blueprint.metrics?.monthlyRequired?.toLocaleString()}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Timeline (Months)</div>
                <div className="stat-value">{blueprint.metrics?.timelineMonths}</div>
              </div>
            </div>

            <div className="card">
              <h2 className="card-title">Action Steps</h2>
              <div style={{ marginTop: '16px' }}>
                {blueprint.action_steps?.map((step, idx) => (
                  <div 
                    key={idx}
                    style={{
                      padding: '16px',
                      background: 'var(--bg-secondary)',
                      borderRadius: '8px',
                      marginBottom: '12px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: '600', marginBottom: '4px' }}>{step.step}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                        Timeline: {step.timeline}
                      </div>
                    </div>
                    <span className={`badge badge-${step.priority === 'high' ? 'accelerator' : 'pro'}`}>
                      {step.priority}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {blueprint.risks && blueprint.risks.length > 0 && (
              <div className="card">
                <h2 className="card-title">Risks & Considerations</h2>
                <ul style={{ marginTop: '16px', paddingLeft: '20px' }}>
                  {blueprint.risks.map((risk, idx) => (
                    <li key={idx} style={{ marginBottom: '8px', color: 'var(--text-secondary)' }}>
                      {risk}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="card" style={{ textAlign: 'center', padding: '32px' }}>
              <TrendingUp size={48} style={{ color: 'var(--success)', margin: '0 auto 16px' }} />
              <div style={{ fontSize: '18px', fontWeight: '600', marginBottom: '8px' }}>
                Confidence Score
              </div>
              <div style={{ fontSize: '48px', fontWeight: 'bold', color: 'var(--primary)' }}>
                {Math.round(blueprint.confidence_score * 100)}%
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default CapitalBlueprint;
