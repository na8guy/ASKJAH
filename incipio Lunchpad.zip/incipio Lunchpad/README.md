# Incipio Launchpad

AI-powered UK property acceleration infrastructure platform - Full-stack production-ready fintech SaaS application.

## 🚀 Features

- **Full-Stack Architecture**: React frontend + Node.js/Express backend + PostgreSQL database
- **AI Orchestration**: Claude AI integration for financial planning, property analysis, and JV matching
- **Payment Processing**: Complete Stripe integration with subscriptions and webhooks
- **Role-Based Access**: FREE, PRO, ACCELERATOR, ADMIN, PARTNER roles
- **JV Engine**: Joint Venture team management, matching, and project tracking
- **Background Jobs**: Bull queue for heavy AI computations
- **Cron Services**: Automated reminders and monitoring
- **Secure Documents**: Encrypted file storage with access control
- **Production Ready**: Render deployment with separate web, worker, and cron services

## 📋 Prerequisites

- Node.js 18+ 
- PostgreSQL 14+
- Redis 6+
- Stripe account
- Claude API key (Anthropic)

## 🛠️ Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
cd frontend && npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your actual credentials
```

4. Set up the database:
```bash
npm run migrate
```

5. Run in development:
```bash
npm run dev
```

## 🏗️ Architecture

### Services
- **Web API**: Main Express server with REST endpoints
- **Worker**: Background job processor for AI tasks
- **Cron**: Scheduled reminder and monitoring service

### Database Schema
- Users & Authentication
- Subscriptions (Stripe integration)
- Financial Profiles & Capital Blueprints
- Income Plans & Side Hustles
- Mortgage Readiness & BTL Strategies
- JV System (Profiles, Teams, Projects, Contracts)
- Deals & Simulations
- Documents & Audit Logs

### AI Functions
- Capital Blueprint Generation
- Savings Optimization
- Mortgage Readiness Analysis
- Income Acceleration Analysis
- BTL Strategy Modeling
- Property Sourcing
- JV Matching & Contract Generation
- Deal Simulation
- Credit Optimization
- Portfolio Scaling

## 🔒 Security

- JWT authentication
- Rate limiting
- Input validation & sanitization
- CORS configuration
- Helmet security headers
- Encrypted file storage
- Audit logging
- Role-based access control

## 🚢 Deployment

Deploy to Render using the included `render.yaml`:

```bash
# Connect your GitHub repo to Render
# Render will automatically:
# - Create PostgreSQL database
# - Create Redis instance
# - Deploy web, worker, and cron services
# - Set up environment variables
```

## 📝 API Documentation

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh JWT token

### Payments
- `POST /api/payments/create-checkout` - Create Stripe checkout
- `POST /api/payments/webhook` - Stripe webhook handler
- `GET /api/payments/portal` - Customer portal session

### AI Services
- `POST /api/ai/capital-blueprint` - Generate capital blueprint
- `POST /api/ai/mortgage-readiness` - Run mortgage readiness
- `POST /api/ai/jv-matching` - Match JV partners
- `POST /api/ai/deal-simulation` - Simulate deal

### JV Engine
- `POST /api/jv/profiles` - Create JV profile
- `GET /api/jv/matches` - Get matched partners
- `POST /api/jv/teams` - Create JV team
- `POST /api/jv/projects` - Create JV project

## 📄 License

MIT
