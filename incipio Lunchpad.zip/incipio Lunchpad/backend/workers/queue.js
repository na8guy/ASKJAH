const Queue = require('bull');
const { query } = require('../config/database');

// Create Bull queue
const jobQueue = new Queue('incipio-jobs', process.env.REDIS_URL || 'redis://localhost:6379', {
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

// Add job to queue
async function addJob(jobType, data, options = {}) {
  try {
    // Store job in database
    const dbJob = await query(
      `INSERT INTO background_jobs (job_type, job_data, status, priority)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [jobType, JSON.stringify(data), 'pending', options.priority || 0]
    );

    // Add to Bull queue
    const job = await jobQueue.add(jobType, {
      ...data,
      dbJobId: dbJob.rows[0].id
    }, options);

    // Update with Bull job ID
    await query(
      'UPDATE background_jobs SET job_id = $1 WHERE id = $2',
      [job.id.toString(), dbJob.rows[0].id]
    );

    return { id: dbJob.rows[0].id, bullJobId: job.id };
  } catch (error) {
    console.error('Error adding job:', error);
    throw error;
  }
}

// Get job status
async function getJobStatus(jobId) {
  try {
    const result = await query(
      'SELECT * FROM background_jobs WHERE id = $1',
      [jobId]
    );

    if (result.rows.length === 0) {
      return null;
    }

    const dbJob = result.rows[0];
    
    // If job has Bull ID, get Bull status too
    if (dbJob.job_id) {
      const bullJob = await jobQueue.getJob(dbJob.job_id);
      if (bullJob) {
        const state = await bullJob.getState();
        return {
          ...dbJob,
          bullState: state,
          progress: bullJob.progress()
        };
      }
    }

    return dbJob;
  } catch (error) {
    console.error('Error getting job status:', error);
    throw error;
  }
}

// Mark job as started
async function markJobStarted(dbJobId) {
  await query(
    'UPDATE background_jobs SET status = $1, started_at = CURRENT_TIMESTAMP WHERE id = $2',
    ['running', dbJobId]
  );
}

// Mark job as completed
async function markJobCompleted(dbJobId, result) {
  await query(
    `UPDATE background_jobs SET status = $1, result = $2, completed_at = CURRENT_TIMESTAMP
     WHERE id = $3`,
    ['completed', JSON.stringify(result), dbJobId]
  );
}

// Mark job as failed
async function markJobFailed(dbJobId, error) {
  await query(
    `UPDATE background_jobs SET status = $1, error = $2, completed_at = CURRENT_TIMESTAMP,
     attempts = attempts + 1
     WHERE id = $3`,
    ['failed', error.message, dbJobId]
  );
}

module.exports = {
  jobQueue,
  addJob,
  getJobStatus,
  markJobStarted,
  markJobCompleted,
  markJobFailed
};
