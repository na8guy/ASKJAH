const express = require('express');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { query } = require('../config/database');
const { logAudit } = require('../utils/auditLogger');

const router = express.Router();

// Create Deal
router.post('/', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const {
      dealName, propertyAddress, propertyType, purchasePrice,
      depositRequired, estimatedRefurbCost, estimatedValuePostRefurb,
      estimatedRentalIncome, dealAnalysis, sourcingMethod, teamId
    } = req.body;

    const result = await query(
      `INSERT INTO deals (
        user_id, team_id, deal_name, property_address, property_type,
        purchase_price, deposit_required, estimated_refurb_cost,
        estimated_value_post_refurb, estimated_rental_income,
        deal_analysis, sourcing_method
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [req.user.id, teamId, dealName, propertyAddress, propertyType,
       purchasePrice, depositRequired, estimatedRefurbCost,
       estimatedValuePostRefurb, estimatedRentalIncome,
       JSON.stringify(dealAnalysis), sourcingMethod]
    );

    await logAudit({
      userId: req.user.id,
      action: 'DEAL_CREATED',
      entityType: 'deal',
      entityId: result.rows[0].id
    });

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Deal creation error:', error);
    res.status(500).json({ error: 'Failed to create deal' });
  }
});

// Get Deals
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM deals WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get deals' });
  }
});

// Update Deal Status
router.put('/:id/status', authenticateToken, async (req, res) => {
  try {
    const { status } = req.body;
    const result = await query(
      'UPDATE deals SET status = $1 WHERE id = $2 AND user_id = $3 RETURNING *',
      [status, req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Deal not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update deal' });
  }
});

module.exports = router;
