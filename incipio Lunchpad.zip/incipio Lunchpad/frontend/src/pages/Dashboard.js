import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { TrendingUp, DollarSign, Target, Briefcase } from 'lucide-react';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await axios.get(`${API_URL}/financial/dashboard-stats`);
      setStats(response.data);
    } catch (error) {
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="loading-spinner">Loading dashboard...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px' }}>
          Dashboard
        </h1>

        <div className="stats-grid">
          <div className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div className="stat-label">Current Savings</div>
                <div className="stat-value">
                  £{stats?.profile?.current_savings?.toLocaleString() || '0'}
                </div>
              </div>
              <DollarSign size={32} style={{ color: 'var(--success)' }} />
            </div>
          </div>

          <div className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div className="stat-label">Target Deposit</div>
                <div className="stat-value">
                  £{stats?.profile?.target_deposit?.toLocaleString() || '0'}
                </div>
              </div>
              <Target size={32} style={{ color: 'var(--primary)' }} />
            </div>
          </div>

          <div className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div className="stat-label">Blueprints Created</div>
                <div className="stat-value">{stats?.blueprintsCount || 0}</div>
              </div>
              <TrendingUp size={32} style={{ color: 'var(--secondary)' }} />
            </div>
          </div>

          <div className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div className="stat-label">Active Side Hustles</div>
                <div className="stat-value">{stats?.activeHustles || 0}</div>
                <div className="stat-change positive">
                  +£{stats?.totalSideIncome?.toLocaleString() || '0'}/mo
                </div>
              </div>
              <Briefcase size={32} style={{ color: 'var(--warning)' }} />
            </div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px', marginTop: '24px' }}>
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Quick Actions</h2>
            </div>
            <div style={{ display: 'grid', gap: '12px' }}>
              <button className="btn btn-primary">Generate Capital Blueprint</button>
              <button className="btn btn-outline">Run Mortgage Readiness Check</button>
              <button className="btn btn-outline">Analyze Income Opportunities</button>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Progress</h2>
            </div>
            {stats?.profile ? (
              <div>
                <div style={{ marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
                      Savings Progress
                    </span>
                    <span style={{ fontSize: '14px', fontWeight: '600' }}>
                      {Math.min(100, ((stats.profile.current_savings / stats.profile.target_deposit) * 100).toFixed(0))}%
                    </span>
                  </div>
                  <div style={{ height: '8px', background: 'var(--bg-secondary)', borderRadius: '4px', overflow: 'hidden' }}>
                    <div style={{
                      height: '100%',
                      width: `${Math.min(100, (stats.profile.current_savings / stats.profile.target_deposit) * 100)}%`,
                      background: 'var(--success)',
                      transition: 'width 0.3s'
                    }}></div>
                  </div>
                </div>
              </div>
            ) : (
              <p style={{ color: 'var(--text-secondary)' }}>
                Complete your financial profile to see progress
              </p>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
