import React from 'react';
import { useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { Check } from 'lucide-react';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const Pricing = () => {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleCheckout = async (planType) => {
    if (!isAuthenticated) {
      navigate('/signup');
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/payments/create-checkout`, { planType });
      window.location.href = response.data.url;
    } catch (error) {
      toast.error('Failed to start checkout');
    }
  };

  const plans = [
    {
      name: 'FREE',
      price: '£0',
      period: 'forever',
      features: [
        'Financial Profile',
        'Basic Dashboard',
        'Partner Directory Access',
        'Community Support'
      ],
      cta: 'Get Started',
      planType: 'FREE'
    },
    {
      name: 'PRO',
      price: '£29',
      period: 'per month',
      features: [
        'Everything in FREE',
        'AI Capital Blueprint Generator',
        'Mortgage Readiness Analysis',
        'Income Acceleration Planner',
        'Savings Optimizer',
        'BTL Strategy Analyzer',
        'Priority Support'
      ],
      cta: 'Upgrade to PRO',
      planType: 'PRO',
      popular: true
    },
    {
      name: 'ACCELERATOR',
      price: '£497',
      period: 'one-time',
      features: [
        'Everything in PRO',
        'Full JV Engine Access',
        'AI JV Partner Matching',
        'Team Workspace & Projects',
        'JV Contract Generator',
        'Deal Analysis & Tracking',
        'Portfolio Scaling Simulations',
        'Bank Statement AI Analysis',
        'Dedicated Support',
        'Quarterly Strategy Calls'
      ],
      cta: 'Join Accelerator',
      planType: 'ACCELERATOR'
    }
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-secondary)', padding: '48px 20px' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '64px' }}>
          <h1 style={{ fontSize: '48px', fontWeight: 'bold', marginBottom: '16px' }}>
            Choose Your Plan
          </h1>
          <p style={{ fontSize: '20px', color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto' }}>
            Accelerate your UK property journey with AI-powered tools
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '32px', maxWidth: '1200px', margin: '0 auto' }}>
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className="card"
              style={{
                position: 'relative',
                border: plan.popular ? '2px solid var(--primary)' : '1px solid var(--border)',
                transform: plan.popular ? 'scale(1.05)' : 'scale(1)',
                transition: 'transform 0.2s'
              }}
            >
              {plan.popular && (
                <div style={{
                  position: 'absolute',
                  top: '-12px',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  background: 'var(--primary)',
                  color: 'white',
                  padding: '4px 16px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  fontWeight: '600'
                }}>
                  MOST POPULAR
                </div>
              )}

              <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                <h3 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '8px' }}>
                  {plan.name}
                </h3>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: '4px' }}>
                  <span style={{ fontSize: '48px', fontWeight: 'bold', color: 'var(--primary)' }}>
                    {plan.price}
                  </span>
                  <span style={{ color: 'var(--text-secondary)' }}>
                    {plan.period}
                  </span>
                </div>
              </div>

              <ul style={{ listStyle: 'none', marginBottom: '32px' }}>
                {plan.features.map((feature, idx) => (
                  <li key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                    <Check size={20} style={{ color: 'var(--success)', flexShrink: 0 }} />
                    <span style={{ fontSize: '14px' }}>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                className={plan.popular ? 'btn btn-primary' : 'btn btn-outline'}
                style={{ width: '100%' }}
                onClick={() => handleCheckout(plan.planType)}
                disabled={user?.role === plan.planType}
              >
                {user?.role === plan.planType ? 'Current Plan' : plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;
