const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const { query } = require('../config/database');
const { logAudit } = require('../utils/auditLogger');

const router = express.Router();

// Create/Update Financial Profile
router.post('/profile', authenticateToken, async (req, res) => {
  try {
    const {
      annualIncome,
      monthlyExpenses,
      currentSavings,
      monthlySavingsTarget,
      debtTotal,
      creditScore,
      employmentStatus,
      employmentYears,
      age,
      dependents,
      targetDeposit,
      targetTimelineMonths,
      riskTolerance
    } = req.body;

    // Check if profile exists
    const existing = await query(
      'SELECT id FROM financial_profiles WHERE user_id = $1',
      [req.user.id]
    );

    let result;
    if (existing.rows.length > 0) {
      // Update
      result = await query(
        `UPDATE financial_profiles SET
          annual_income = $1, monthly_expenses = $2, current_savings = $3,
          monthly_savings_target = $4, debt_total = $5, credit_score = $6,
          employment_status = $7, employment_years = $8, age = $9,
          dependents = $10, target_deposit = $11, target_timeline_months = $12,
          risk_tolerance = $13
         WHERE user_id = $14 RETURNING *`,
        [annualIncome, monthlyExpenses, currentSavings, monthlySavingsTarget,
         debtTotal, creditScore, employmentStatus, employmentYears, age,
         dependents, targetDeposit, targetTimelineMonths, riskTolerance, req.user.id]
      );
    } else {
      // Create
      result = await query(
        `INSERT INTO financial_profiles (
          user_id, annual_income, monthly_expenses, current_savings,
          monthly_savings_target, debt_total, credit_score, employment_status,
          employment_years, age, dependents, target_deposit,
          target_timeline_months, risk_tolerance
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
         RETURNING *`,
        [req.user.id, annualIncome, monthlyExpenses, currentSavings,
         monthlySavingsTarget, debtTotal, creditScore, employmentStatus,
         employmentYears, age, dependents, targetDeposit, targetTimelineMonths,
         riskTolerance]
      );
    }

    await logAudit({
      userId: req.user.id,
      action: 'FINANCIAL_PROFILE_UPDATED',
      entityType: 'financial_profile',
      entityId: result.rows[0].id
    });

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Financial profile error:', error);
    res.status(500).json({ error: 'Failed to save financial profile' });
  }
});

// Get Financial Profile
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM financial_profiles WHERE user_id = $1',
      [req.user.id]
    );
    res.json(result.rows[0] || null);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get financial profile' });
  }
});

// Create Capital Blueprint
router.post('/capital-blueprint', authenticateToken, async (req, res) => {
  try {
    const { financialProfileId, blueprintData, summary, targetAmount, timelineMonths, confidenceScore } = req.body;

    const result = await query(
      `INSERT INTO capital_blueprints (
        user_id, financial_profile_id, blueprint_data, summary,
        target_amount, timeline_months, confidence_score
       ) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [req.user.id, financialProfileId, JSON.stringify(blueprintData),
       summary, targetAmount, timelineMonths, confidenceScore]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Capital blueprint error:', error);
    res.status(500).json({ error: 'Failed to create capital blueprint' });
  }
});

// Get Capital Blueprints
router.get('/capital-blueprints', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      `SELECT * FROM capital_blueprints 
       WHERE user_id = $1 
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get capital blueprints' });
  }
});

// Create Side Hustle
router.post('/side-hustle', authenticateToken, async (req, res) => {
  try {
    const {
      name, description, category, estimatedMonthlyIncome,
      timeCommitmentHours, startupCost, status
    } = req.body;

    const result = await query(
      `INSERT INTO side_hustles (
        user_id, name, description, category, estimated_monthly_income,
        time_commitment_hours, startup_cost, status
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [req.user.id, name, description, category, estimatedMonthlyIncome,
       timeCommitmentHours, startupCost, status || 'idea']
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Side hustle error:', error);
    res.status(500).json({ error: 'Failed to create side hustle' });
  }
});

// Get Side Hustles
router.get('/side-hustles', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM side_hustles WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get side hustles' });
  }
});

// Update Side Hustle
router.put('/side-hustle/:id', authenticateToken, async (req, res) => {
  try {
    const { actualMonthlyIncome, status } = req.body;

    const result = await query(
      `UPDATE side_hustles 
       SET actual_monthly_income = $1, status = $2
       WHERE id = $3 AND user_id = $4
       RETURNING *`,
      [actualMonthlyIncome, status, req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Side hustle not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update side hustle' });
  }
});

// Get Dashboard Stats
router.get('/dashboard-stats', authenticateToken, async (req, res) => {
  try {
    const profile = await query(
      'SELECT * FROM financial_profiles WHERE user_id = $1',
      [req.user.id]
    );

    const blueprints = await query(
      'SELECT COUNT(*) as count FROM capital_blueprints WHERE user_id = $1',
      [req.user.id]
    );

    const hustles = await query(
      'SELECT COUNT(*) as count, SUM(actual_monthly_income) as total_income FROM side_hustles WHERE user_id = $1 AND status = $2',
      [req.user.id, 'active']
    );

    res.json({
      profile: profile.rows[0],
      blueprintsCount: parseInt(blueprints.rows[0].count),
      activeHustles: parseInt(hustles.rows[0].count),
      totalSideIncome: parseFloat(hustles.rows[0].total_income || 0)
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get dashboard stats' });
  }
});

module.exports = router;
