import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { 
  LayoutDashboard, TrendingUp, Users, FileText, 
  Building, UserCircle, Settings, LogOut, Sun, Moon 
} from 'lucide-react';

const Layout = ({ children }) => {
  const { user, logout, hasRole } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, minRole: 'FREE' },
    { path: '/financial-profile', label: 'Financial Profile', icon: UserCircle, minRole: 'FREE' },
    { path: '/capital-blueprint', label: 'Capital Blueprint', icon: TrendingUp, minRole: 'PRO' },
    { path: '/jv', label: 'JV Hub', icon: Users, minRole: 'ACCELERATOR' },
    { path: '/deals', label: 'Deals', icon: Building, minRole: 'ACCELERATOR' },
    { path: '/partners', label: 'Partners', icon: FileText, minRole: 'FREE' },
    { path: '/settings', label: 'Settings', icon: Settings, minRole: 'FREE' },
  ];

  return (
    <div className="layout">
      <aside className="sidebar">
        <div style={{ padding: '0 24px', marginBottom: '32px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--primary)' }}>
            Incipio
          </h1>
          <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
            Launchpad
          </p>
          
          {user && (
            <div style={{ marginTop: '20px', padding: '12px', background: 'var(--bg-secondary)', borderRadius: '8px' }}>
              <p style={{ fontSize: '14px', fontWeight: '600' }}>{user.firstName} {user.lastName}</p>
              <span className={`badge badge-${user.role.toLowerCase()}`}>{user.role}</span>
            </div>
          )}
        </div>

        <nav>
          {navItems.map(item => {
            if (!hasRole(item.minRole)) return null;
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link 
                key={item.path}
                to={item.path}
                className={`nav-link ${isActive ? 'active' : ''}`}
              >
                <Icon className="nav-icon" />
                {item.label}
              </Link>
            );
          })}

          <button 
            onClick={logout}
            className="nav-link"
            style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', marginTop: '20px' }}
          >
            <LogOut className="nav-icon" />
            Logout
          </button>
        </nav>
      </aside>

      <main className="main-content">
        {children}
      </main>

      <button onClick={toggleTheme} className="theme-toggle">
        {theme === 'light' ? <Moon size={24} /> : <Sun size={24} />}
      </button>
    </div>
  );
};

export default Layout;
