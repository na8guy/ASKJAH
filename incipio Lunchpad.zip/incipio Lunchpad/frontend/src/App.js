import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import PrivateRoute from './components/PrivateRoute';

// Pages
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Pricing from './pages/Pricing';
import FinancialProfile from './pages/FinancialProfile';
import CapitalBlueprint from './pages/CapitalBlueprint';
import JVHub from './pages/JVHub';
import JVTeam from './pages/JVTeam';
import Deals from './pages/Deals';
import Partners from './pages/Partners';
import Settings from './pages/Settings';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Toaster position="top-right" />
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/pricing" element={<Pricing />} />
            
            <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
            <Route path="/financial-profile" element={<PrivateRoute><FinancialProfile /></PrivateRoute>} />
            <Route path="/capital-blueprint" element={<PrivateRoute minRole="PRO"><CapitalBlueprint /></PrivateRoute>} />
            <Route path="/jv" element={<PrivateRoute minRole="ACCELERATOR"><JVHub /></PrivateRoute>} />
            <Route path="/jv/team/:teamId" element={<PrivateRoute minRole="ACCELERATOR"><JVTeam /></PrivateRoute>} />
            <Route path="/deals" element={<PrivateRoute minRole="ACCELERATOR"><Deals /></PrivateRoute>} />
            <Route path="/partners" element={<PrivateRoute><Partners /></PrivateRoute>} />
            <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />
            
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
