require('dotenv').config();
const { jobQueue, markJobStarted, markJobCompleted, markJobFailed } = require('./workers/queue');
const claudeService = require('./services/claudeService');
const { query } = require('./config/database');

console.log('🔧 Worker starting...');

// Process JV Matching Jobs
jobQueue.process('jv-matching', 2, async (job) => {
  const { userId, profileData, filters, dbJobId } = job.data;

  try {
    await markJobStarted(dbJobId);
    job.progress(10);

    // Get candidates
    const candidates = await query(
      `SELECT p.*, u.first_name, u.last_name
       FROM jv_profiles p
       JOIN users u ON p.user_id = u.id
       WHERE p.is_active = true AND p.user_id != $1`,
      [userId]
    );

    job.progress(30);

    // Run AI matching
    const matches = await claudeService.runJVMatching(
      userId,
      profileData,
      candidates.rows
    );

    job.progress(80);

    // Store results
    await query(
      `INSERT INTO simulations (user_id, simulation_type, input_data, output_data, status)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, 'jv-matching', JSON.stringify({ profileData, filters }),
       JSON.stringify(matches), 'completed']
    );

    job.progress(100);
    await markJobCompleted(dbJobId, matches);

    return matches;
  } catch (error) {
    console.error('JV matching job failed:', error);
    await markJobFailed(dbJobId, error);
    throw error;
  }
});

// Process Portfolio Simulation Jobs
jobQueue.process('portfolio-simulation', 1, async (job) => {
  const { userId, portfolioData, scalingParameters, dbJobId } = job.data;

  try {
    await markJobStarted(dbJobId);
    job.progress(10);

    const systemPrompt = `You are a UK property portfolio scaling expert. Simulate portfolio growth.

Return ONLY valid JSON:
{
  "summary": "Portfolio scaling simulation",
  "metrics": {
    "currentValue": number,
    "projectedValue5Year": number,
    "totalPropertiesTarget": number,
    "capitalRequired": number,
    "projectedCashFlow": number
  },
  "projections": {
    "year1": {},
    "year2": {},
    "year3": {},
    "year4": {},
    "year5": {}
  },
  "risks": [],
  "action_steps": [],
  "confidence_score": number
}`;

    const userMessage = `Portfolio: ${JSON.stringify(portfolioData)}
Scaling Parameters: ${JSON.stringify(scalingParameters)}

Simulate portfolio growth over 5 years.`;

    job.progress(30);

    const response = await claudeService.callClaude(systemPrompt, userMessage, 8000);
    const result = JSON.parse(response);

    job.progress(80);

    // Store simulation
    await query(
      `INSERT INTO simulations (user_id, simulation_type, input_data, output_data, status)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, 'portfolio-simulation', JSON.stringify({ portfolioData, scalingParameters }),
       JSON.stringify(result), 'completed']
    );

    job.progress(100);
    await markJobCompleted(dbJobId, result);

    return result;
  } catch (error) {
    console.error('Portfolio simulation job failed:', error);
    await markJobFailed(dbJobId, error);
    throw error;
  }
});

// Process Bank Statement Analysis Jobs
jobQueue.process('bank-statement-analysis', 2, async (job) => {
  const { userId, statementData, dbJobId } = job.data;

  try {
    await markJobStarted(dbJobId);
    job.progress(20);

    const systemPrompt = `You are a financial analyst. Analyze bank statement data.

Return ONLY valid JSON:
{
  "summary": "Financial health overview",
  "metrics": {
    "averageMonthlyIncome": number,
    "averageMonthlyExpenses": number,
    "savingsRate": number,
    "spendingCategories": {}
  },
  "projections": {},
  "risks": ["spending pattern issue"],
  "action_steps": [{"step": "reduce spending on X", "priority": "high"}],
  "confidence_score": number
}`;

    const userMessage = `Bank Statement Data: ${JSON.stringify(statementData)}`;

    job.progress(50);
    const response = await claudeService.callClaude(systemPrompt, userMessage, 4096);
    const result = JSON.parse(response);

    job.progress(90);
    await markJobCompleted(dbJobId, result);
    job.progress(100);

    return result;
  } catch (error) {
    console.error('Bank statement analysis failed:', error);
    await markJobFailed(dbJobId, error);
    throw error;
  }
});

// Event listeners
jobQueue.on('completed', (job, result) => {
  console.log(`✓ Job ${job.id} completed:`, job.data.dbJobId);
});

jobQueue.on('failed', (job, err) => {
  console.error(`✗ Job ${job.id} failed:`, err.message);
});

jobQueue.on('stalled', (job) => {
  console.warn(`⚠ Job ${job.id} stalled`);
});

console.log('✓ Worker ready and processing jobs');

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Worker shutting down...');
  await jobQueue.close();
  process.exit(0);
});
