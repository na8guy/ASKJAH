import React from 'react';
import Layout from '../components/Layout';

const Partners = () => {
  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px' }}>
          Partners
        </h1>
        <div className="card">
          <p style={{ color: 'var(--text-secondary)' }}>
            Partner directory coming soon...
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Partners;
