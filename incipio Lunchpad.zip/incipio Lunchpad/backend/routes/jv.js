const express = require('express');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { query, transaction } = require('../config/database');
const { logAudit } = require('../utils/auditLogger');
const claudeService = require('../services/claudeService');

const router = express.Router();

// Create JV Profile
router.post('/profile', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const {
      profileName, bio, experienceLevel, capitalAvailable,
      timeAvailableHours, skills, preferences, location,
      seekingRoles, offeringRoles
    } = req.body;

    const result = await query(
      `INSERT INTO jv_profiles (
        user_id, profile_name, bio, experience_level, capital_available,
        time_available_hours, skills, preferences, location,
        seeking_roles, offering_roles
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING *`,
      [req.user.id, profileName, bio, experienceLevel, capitalAvailable,
       timeAvailableHours, JSON.stringify(skills), JSON.stringify(preferences),
       location, JSON.stringify(seekingRoles), JSON.stringify(offeringRoles)]
    );

    await logAudit({
      userId: req.user.id,
      action: 'JV_PROFILE_CREATED',
      entityType: 'jv_profile',
      entityId: result.rows[0].id
    });

    res.json(result.rows[0]);
  } catch (error) {
    console.error('JV profile error:', error);
    res.status(500).json({ error: 'Failed to create JV profile' });
  }
});

// Get My JV Profile
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM jv_profiles WHERE user_id = $1 AND is_active = true',
      [req.user.id]
    );
    res.json(result.rows[0] || null);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get JV profile' });
  }
});

// Get All Active JV Profiles (for matching)
router.get('/profiles', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const result = await query(
      `SELECT p.*, u.first_name, u.last_name, u.email
       FROM jv_profiles p
       JOIN users u ON p.user_id = u.id
       WHERE p.is_active = true AND p.user_id != $1`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get JV profiles' });
  }
});

// AI-Powered JV Matching
router.post('/find-matches', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const myProfile = await query(
      'SELECT * FROM jv_profiles WHERE user_id = $1 AND is_active = true',
      [req.user.id]
    );

    if (myProfile.rows.length === 0) {
      return res.status(404).json({ error: 'Please create a JV profile first' });
    }

    const candidates = await query(
      `SELECT p.*, u.first_name, u.last_name
       FROM jv_profiles p
       JOIN users u ON p.user_id = u.id
       WHERE p.is_active = true AND p.user_id != $1`,
      [req.user.id]
    );

    const matches = await claudeService.runJVMatching(
      req.user.id,
      myProfile.rows[0],
      candidates.rows
    );

    res.json(matches);
  } catch (error) {
    console.error('JV matching error:', error);
    res.status(500).json({ error: 'Failed to find JV matches' });
  }
});

// Create JV Team
router.post('/team', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const { name, description, invitedUserIds } = req.body;

    const result = await transaction(async (client) => {
      // Create team
      const teamResult = await client.query(
        `INSERT INTO jv_teams (name, description, created_by)
         VALUES ($1, $2, $3) RETURNING *`,
        [name, description, req.user.id]
      );
      const team = teamResult.rows[0];

      // Add creator as first member
      await client.query(
        `INSERT INTO jv_team_members (team_id, user_id, role, status, voting_power)
         VALUES ($1, $2, $3, $4, $5)`,
        [team.id, req.user.id, 'Founder', 'active', 1]
      );

      // Invite other members
      if (invitedUserIds && invitedUserIds.length > 0) {
        for (const userId of invitedUserIds) {
          await client.query(
            `INSERT INTO jv_team_members (team_id, user_id, status, voting_power)
             VALUES ($1, $2, $3, $4)`,
            [team.id, userId, 'invited', 1]
          );
        }
      }

      return team;
    });

    await logAudit({
      userId: req.user.id,
      action: 'JV_TEAM_CREATED',
      entityType: 'jv_team',
      entityId: result.id
    });

    res.json(result);
  } catch (error) {
    console.error('JV team error:', error);
    res.status(500).json({ error: 'Failed to create JV team' });
  }
});

// Get My Teams
router.get('/teams', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      `SELECT t.*, 
        (SELECT COUNT(*) FROM jv_team_members WHERE team_id = t.id) as member_count
       FROM jv_teams t
       JOIN jv_team_members m ON t.id = m.team_id
       WHERE m.user_id = $1 AND m.status IN ('active', 'invited')
       ORDER BY t.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get teams' });
  }
});

// Get Team Details
router.get('/team/:teamId', authenticateToken, async (req, res) => {
  try {
    // Check if user is a member
    const memberCheck = await query(
      'SELECT * FROM jv_team_members WHERE team_id = $1 AND user_id = $2',
      [req.params.teamId, req.user.id]
    );

    if (memberCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Not a member of this team' });
    }

    const team = await query('SELECT * FROM jv_teams WHERE id = $1', [req.params.teamId]);
    const members = await query(
      `SELECT m.*, u.first_name, u.last_name, u.email, p.experience_level
       FROM jv_team_members m
       JOIN users u ON m.user_id = u.id
       LEFT JOIN jv_profiles p ON m.jv_profile_id = p.id
       WHERE m.team_id = $1`,
      [req.params.teamId]
    );

    res.json({
      team: team.rows[0],
      members: members.rows
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get team details' });
  }
});

// Accept Team Invitation
router.post('/team/:teamId/accept', authenticateToken, async (req, res) => {
  try {
    const result = await query(
      `UPDATE jv_team_members
       SET status = 'active', joined_at = CURRENT_TIMESTAMP
       WHERE team_id = $1 AND user_id = $2 AND status = 'invited'
       RETURNING *`,
      [req.params.teamId, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invitation not found' });
    }

    await logAudit({
      userId: req.user.id,
      action: 'JV_TEAM_JOINED',
      entityType: 'jv_team',
      entityId: req.params.teamId
    });

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to accept invitation' });
  }
});

// Create JV Project
router.post('/project', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const {
      teamId, projectName, description, projectType, totalBudget,
      targetRoiPercentage, startDate, targetCompletionDate
    } = req.body;

    // Verify team membership
    const memberCheck = await query(
      'SELECT * FROM jv_team_members WHERE team_id = $1 AND user_id = $2 AND status = $3',
      [teamId, req.user.id, 'active']
    );

    if (memberCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Not an active team member' });
    }

    const result = await query(
      `INSERT INTO jv_projects (
        team_id, project_name, description, project_type, total_budget,
        target_roi_percentage, start_date, target_completion_date
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [teamId, projectName, description, projectType, totalBudget,
       targetRoiPercentage, startDate, targetCompletionDate]
    );

    await logAudit({
      userId: req.user.id,
      action: 'JV_PROJECT_CREATED',
      entityType: 'jv_project',
      entityId: result.rows[0].id
    });

    res.json(result.rows[0]);
  } catch (error) {
    console.error('JV project error:', error);
    res.status(500).json({ error: 'Failed to create JV project' });
  }
});

// Get Team Projects
router.get('/team/:teamId/projects', authenticateToken, async (req, res) => {
  try {
    // Verify membership
    const memberCheck = await query(
      'SELECT * FROM jv_team_members WHERE team_id = $1 AND user_id = $2',
      [req.params.teamId, req.user.id]
    );

    if (memberCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Not a team member' });
    }

    const result = await query(
      'SELECT * FROM jv_projects WHERE team_id = $1 ORDER BY created_at DESC',
      [req.params.teamId]
    );

    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get projects' });
  }
});

// Generate JV Contract
router.post('/team/:teamId/generate-contract', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const teamId = req.params.teamId;

    // Get team and members data
    const team = await query('SELECT * FROM jv_teams WHERE id = $1', [teamId]);
    const members = await query(
      `SELECT m.*, u.first_name, u.last_name, p.capital_available
       FROM jv_team_members m
       JOIN users u ON m.user_id = u.id
       LEFT JOIN jv_profiles p ON m.jv_profile_id = p.id
       WHERE m.team_id = $1 AND m.status = 'active'`,
      [teamId]
    );

    const teamData = {
      id: teamId,
      name: team.rows[0].name,
      members: members.rows,
      totalCapital: team.rows[0].total_capital_pooled,
      projectType: 'Property Investment'
    };

    const contractData = await claudeService.generateJVContract(req.user.id, teamData);

    // Save contract
    const result = await query(
      `INSERT INTO jv_contracts (team_id, contract_type, contract_data, status)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [teamId, 'JV Agreement', JSON.stringify(contractData), 'draft']
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Contract generation error:', error);
    res.status(500).json({ error: 'Failed to generate contract' });
  }
});

module.exports = router;
