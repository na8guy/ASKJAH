import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const FinancialProfile = () => {
  const [profile, setProfile] = useState({
    annualIncome: '',
    monthlyExpenses: '',
    currentSavings: '',
    monthlySavingsTarget: '',
    debtTotal: '',
    creditScore: '',
    employmentStatus: '',
    employmentYears: '',
    age: '',
    dependents: '',
    targetDeposit: '',
    targetTimelineMonths: '',
    riskTolerance: 'medium'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await axios.get(`${API_URL}/financial/profile`);
      if (response.data) {
        setProfile({
          annualIncome: response.data.annual_income || '',
          monthlyExpenses: response.data.monthly_expenses || '',
          currentSavings: response.data.current_savings || '',
          monthlySavingsTarget: response.data.monthly_savings_target || '',
          debtTotal: response.data.debt_total || '',
          creditScore: response.data.credit_score || '',
          employmentStatus: response.data.employment_status || '',
          employmentYears: response.data.employment_years || '',
          age: response.data.age || '',
          dependents: response.data.dependents || '',
          targetDeposit: response.data.target_deposit || '',
          targetTimelineMonths: response.data.target_timeline_months || '',
          riskTolerance: response.data.risk_tolerance || 'medium'
        });
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    }
  };

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(`${API_URL}/financial/profile`, profile);
      toast.success('Financial profile saved successfully!');
    } catch (error) {
      toast.error('Failed to save profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px' }}>
          Financial Profile
        </h1>

        <div className="card">
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
              <div className="form-group">
                <label className="form-label">Annual Income (£)</label>
                <input
                  type="number"
                  name="annualIncome"
                  className="form-input"
                  value={profile.annualIncome}
                  onChange={handleChange}
                  placeholder="50000"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Monthly Expenses (£)</label>
                <input
                  type="number"
                  name="monthlyExpenses"
                  className="form-input"
                  value={profile.monthlyExpenses}
                  onChange={handleChange}
                  placeholder="2000"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Current Savings (£)</label>
                <input
                  type="number"
                  name="currentSavings"
                  className="form-input"
                  value={profile.currentSavings}
                  onChange={handleChange}
                  placeholder="10000"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Monthly Savings Target (£)</label>
                <input
                  type="number"
                  name="monthlySavingsTarget"
                  className="form-input"
                  value={profile.monthlySavingsTarget}
                  onChange={handleChange}
                  placeholder="500"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Total Debt (£)</label>
                <input
                  type="number"
                  name="debtTotal"
                  className="form-input"
                  value={profile.debtTotal}
                  onChange={handleChange}
                  placeholder="0"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Credit Score</label>
                <input
                  type="number"
                  name="creditScore"
                  className="form-input"
                  value={profile.creditScore}
                  onChange={handleChange}
                  placeholder="750"
                  min="300"
                  max="850"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Employment Status</label>
                <select
                  name="employmentStatus"
                  className="form-input"
                  value={profile.employmentStatus}
                  onChange={handleChange}
                >
                  <option value="">Select...</option>
                  <option value="Employed Full-Time">Employed Full-Time</option>
                  <option value="Employed Part-Time">Employed Part-Time</option>
                  <option value="Self-Employed">Self-Employed</option>
                  <option value="Contractor">Contractor</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Years in Employment</label>
                <input
                  type="number"
                  name="employmentYears"
                  className="form-input"
                  value={profile.employmentYears}
                  onChange={handleChange}
                  placeholder="5"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Age</label>
                <input
                  type="number"
                  name="age"
                  className="form-input"
                  value={profile.age}
                  onChange={handleChange}
                  placeholder="30"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Dependents</label>
                <input
                  type="number"
                  name="dependents"
                  className="form-input"
                  value={profile.dependents}
                  onChange={handleChange}
                  placeholder="0"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Target Deposit (£)</label>
                <input
                  type="number"
                  name="targetDeposit"
                  className="form-input"
                  value={profile.targetDeposit}
                  onChange={handleChange}
                  placeholder="50000"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Target Timeline (Months)</label>
                <input
                  type="number"
                  name="targetTimelineMonths"
                  className="form-input"
                  value={profile.targetTimelineMonths}
                  onChange={handleChange}
                  placeholder="24"
                />
              </div>

              <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="form-label">Risk Tolerance</label>
                <select
                  name="riskTolerance"
                  className="form-input"
                  value={profile.riskTolerance}
                  onChange={handleChange}
                >
                  <option value="low">Low - Conservative approach</option>
                  <option value="medium">Medium - Balanced approach</option>
                  <option value="high">High - Aggressive growth</option>
                </select>
              </div>
            </div>

            <button type="submit" className="btn btn-primary" style={{ marginTop: '24px' }} disabled={loading}>
              {loading ? 'Saving...' : 'Save Profile'}
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default FinancialProfile;
