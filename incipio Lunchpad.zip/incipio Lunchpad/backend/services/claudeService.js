const axios = require('axios');
const { logAudit } = require('../utils/auditLogger');

const CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';
const CLAUDE_MODEL = 'claude-3-5-sonnet-20241022';

class ClaudeService {
  constructor() {
    this.apiKey = process.env.CLAUDE_API_KEY;
  }

  async callClaude(systemPrompt, userMessage, maxTokens = 4096) {
    try {
      const response = await axios.post(
        CLAUDE_API_URL,
        {
          model: CLAUDE_MODEL,
          max_tokens: maxTokens,
          system: systemPrompt,
          messages: [
            {
              role: 'user',
              content: userMessage
            }
          ]
        },
        {
          headers: {
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json'
          }
        }
      );

      return response.data.content[0].text;
    } catch (error) {
      console.error('Claude API error:', error.response?.data || error.message);
      throw new Error('AI service unavailable');
    }
  }

  async generateCapitalBlueprint(userId, financialData) {
    const systemPrompt = `You are a UK property finance expert. Generate a comprehensive capital accumulation blueprint.
    
Return ONLY valid JSON in this exact structure:
{
  "summary": "Brief overview of the strategy",
  "metrics": {
    "currentSavings": number,
    "targetDeposit": number,
    "monthlyRequired": number,
    "timelineMonths": number
  },
  "projections": {
    "month6": number,
    "month12": number,
    "month18": number,
    "month24": number
  },
  "risks": ["risk1", "risk2"],
  "action_steps": [
    {"step": "description", "priority": "high|medium|low", "timeline": "immediate|1-3 months|3-6 months"}
  ],
  "confidence_score": 0.85
}`;

    const userMessage = `Financial Profile:
- Annual Income: £${financialData.annualIncome}
- Monthly Expenses: £${financialData.monthlyExpenses}
- Current Savings: £${financialData.currentSavings}
- Target Deposit: £${financialData.targetDeposit}
- Debt: £${financialData.debtTotal || 0}
- Credit Score: ${financialData.creditScore || 'N/A'}

Generate a capital blueprint.`;

    const response = await this.callClaude(systemPrompt, userMessage);
    
    // Parse and validate response
    const parsed = JSON.parse(response);
    this.validateStructure(parsed);

    await logAudit({
      userId,
      action: 'AI_CAPITAL_BLUEPRINT',
      entityType: 'ai_request',
      changes: { input: financialData, output: parsed }
    });

    return parsed;
  }

  async runMortgageReadiness(userId, financialData) {
    const systemPrompt = `You are a UK mortgage advisor. Analyze mortgage readiness.

Return ONLY valid JSON:
{
  "summary": "Overall readiness assessment",
  "metrics": {
    "readinessScore": number (0-100),
    "maxBorrowingCapacity": number,
    "recommendedDeposit": number,
    "estimatedMonthlyPayment": number,
    "affordabilityRatio": number
  },
  "projections": {
    "if5PercentDeposit": {},
    "if10PercentDeposit": {},
    "if15PercentDeposit": {}
  },
  "risks": ["gap1", "gap2"],
  "action_steps": [
    {"step": "description", "priority": "high|medium|low", "timeline": "timeframe"}
  ],
  "confidence_score": number
}`;

    const userMessage = `Profile:
- Annual Income: £${financialData.annualIncome}
- Monthly Expenses: £${financialData.monthlyExpenses}
- Current Savings: £${financialData.currentSavings}
- Debt: £${financialData.debtTotal || 0}
- Credit Score: ${financialData.creditScore || 'N/A'}
- Employment: ${financialData.employmentStatus}, ${financialData.employmentYears} years

Analyze mortgage readiness.`;

    const response = await this.callClaude(systemPrompt, userMessage);
    const parsed = JSON.parse(response);
    this.validateStructure(parsed);

    await logAudit({
      userId,
      action: 'AI_MORTGAGE_READINESS',
      entityType: 'ai_request',
      changes: { input: financialData, output: parsed }
    });

    return parsed;
  }

  async runIncomeAccelerationAnalysis(userId, incomeData) {
    const systemPrompt = `You are a UK income optimization expert. Analyze income acceleration opportunities.

Return ONLY valid JSON:
{
  "summary": "Income acceleration strategy overview",
  "metrics": {
    "currentIncome": number,
    "targetIncome": number,
    "gapToClose": number,
    "timelineMonths": number
  },
  "projections": {
    "primaryIncomeGrowth": {},
    "sideHustleIncome": {},
    "totalProjected": {}
  },
  "risks": ["risk1", "risk2"],
  "action_steps": [
    {"step": "description", "priority": "high|medium|low", "timeline": "timeframe", "estimatedIncrease": number}
  ],
  "confidence_score": number
}`;

    const userMessage = `Income Profile:
- Current Annual Income: £${incomeData.currentIncome}
- Target Annual Income: £${incomeData.targetIncome}
- Employment: ${incomeData.employmentStatus}
- Skills: ${incomeData.skills?.join(', ') || 'General'}
- Available Time: ${incomeData.availableHours || 10} hours/week

Generate income acceleration plan.`;

    const response = await this.callClaude(systemPrompt, userMessage);
    const parsed = JSON.parse(response);
    this.validateStructure(parsed);

    await logAudit({
      userId,
      action: 'AI_INCOME_ACCELERATION',
      entityType: 'ai_request',
      changes: { input: incomeData, output: parsed }
    });

    return parsed;
  }

  async runBTLStrategyModel(userId, propertyData) {
    const systemPrompt = `You are a UK Buy-to-Let investment expert. Analyze BTL strategy.

Return ONLY valid JSON:
{
  "summary": "BTL strategy analysis",
  "metrics": {
    "purchasePrice": number,
    "depositRequired": number,
    "estimatedRentalYield": number,
    "monthlyRentalIncome": number,
    "monthlyCosts": number,
    "netCashFlow": number,
    "roiPercentage": number
  },
  "projections": {
    "year1": {},
    "year3": {},
    "year5": {}
  },
  "risks": ["risk1", "risk2"],
  "action_steps": [
    {"step": "description", "priority": "high|medium|low", "timeline": "timeframe"}
  ],
  "confidence_score": number
}`;

    const userMessage = `Property Details:
- Location: ${propertyData.location}
- Property Type: ${propertyData.propertyType}
- Purchase Price: £${propertyData.purchasePrice}
- Estimated Rental Income: £${propertyData.estimatedRentalIncome}/month
- Available Deposit: £${propertyData.depositAmount}

Analyze BTL viability.`;

    const response = await this.callClaude(systemPrompt, userMessage);
    const parsed = JSON.parse(response);
    this.validateStructure(parsed);

    await logAudit({
      userId,
      action: 'AI_BTL_STRATEGY',
      entityType: 'ai_request',
      changes: { input: propertyData, output: parsed }
    });

    return parsed;
  }

  async runJVMatching(userId, profile, candidates) {
    const systemPrompt = `You are a Joint Venture matching expert. Match compatible JV partners.

Return ONLY valid JSON:
{
  "summary": "JV matching analysis",
  "metrics": {
    "totalCandidates": number,
    "topMatchesCount": number,
    "averageCompatibility": number
  },
  "matches": [
    {
      "candidateId": "uuid",
      "compatibilityScore": number (0-100),
      "strengths": ["strength1", "strength2"],
      "synergies": ["synergy1"],
      "considerations": ["consideration1"]
    }
  ],
  "risks": [],
  "action_steps": [
    {"step": "description", "priority": "high|medium|low", "timeline": "timeframe"}
  ],
  "confidence_score": number
}`;

    const userMessage = `Your Profile:
- Capital: £${profile.capitalAvailable}
- Time: ${profile.timeAvailableHours} hours/week
- Skills: ${JSON.stringify(profile.skills)}
- Seeking: ${JSON.stringify(profile.seekingRoles)}
- Offering: ${JSON.stringify(profile.offeringRoles)}

Candidates: ${JSON.stringify(candidates)}

Match compatible JV partners.`;

    const response = await this.callClaude(systemPrompt, userMessage, 8000);
    const parsed = JSON.parse(response);

    await logAudit({
      userId,
      action: 'AI_JV_MATCHING',
      entityType: 'ai_request',
      changes: { candidatesCount: candidates.length }
    });

    return parsed;
  }

  async generateJVContract(userId, teamData) {
    const systemPrompt = `You are a UK legal expert. Generate a JV contract framework.

Return ONLY valid JSON:
{
  "summary": "Contract overview",
  "contractData": {
    "parties": [],
    "capitalContributions": {},
    "equityAllocation": {},
    "responsibilities": {},
    "votingRights": {},
    "profitSharing": {},
    "exitClauses": [],
    "disputeResolution": ""
  },
  "risks": ["legal consideration 1"],
  "action_steps": [
    {"step": "Get legal review", "priority": "high", "timeline": "before signing"}
  ],
  "confidence_score": number
}`;

    const userMessage = `Team: ${teamData.name}
Members: ${JSON.stringify(teamData.members)}
Total Capital: £${teamData.totalCapital}
Project Type: ${teamData.projectType}

Generate JV contract framework.`;

    const response = await this.callClaude(systemPrompt, userMessage, 8000);
    const parsed = JSON.parse(response);

    await logAudit({
      userId,
      action: 'AI_JV_CONTRACT',
      entityType: 'ai_request',
      changes: { teamId: teamData.id }
    });

    return parsed;
  }

  validateStructure(data) {
    if (!data.summary || !data.metrics || !data.action_steps || !data.confidence_score) {
      throw new Error('Invalid AI response structure');
    }
    if (data.confidence_score < 0 || data.confidence_score > 1) {
      throw new Error('Invalid confidence score');
    }
  }
}

module.exports = new ClaudeService();
