-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  role VARCHAR(50) DEFAULT 'FREE' CHECK (role IN ('FREE', 'PRO', 'ACCELERATOR', 'ADMIN', 'PARTNER')),
  is_active BOOLEAN DEFAULT true,
  email_verified BOOLEAN DEFAULT false,
  verification_token VARCHAR(255),
  reset_password_token VARCHAR(255),
  reset_password_expires TIMESTAMP,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Subscriptions table
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stripe_customer_id VARCHAR(255) UNIQUE,
  stripe_subscription_id VARCHAR(255) UNIQUE,
  plan_type VARCHAR(50) CHECK (plan_type IN ('FREE', 'PRO', 'ACCELERATOR')),
  status VARCHAR(50) CHECK (status IN ('active', 'canceled', 'past_due', 'incomplete', 'trialing')),
  current_period_start TIMESTAMP,
  current_period_end TIMESTAMP,
  cancel_at_period_end BOOLEAN DEFAULT false,
  canceled_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_stripe_customer_id ON subscriptions(stripe_customer_id);

-- Financial Profiles table
CREATE TABLE financial_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  annual_income DECIMAL(12, 2),
  monthly_expenses DECIMAL(12, 2),
  current_savings DECIMAL(12, 2),
  monthly_savings_target DECIMAL(12, 2),
  debt_total DECIMAL(12, 2),
  credit_score INTEGER,
  employment_status VARCHAR(100),
  employment_years INTEGER,
  age INTEGER,
  dependents INTEGER,
  target_deposit DECIMAL(12, 2),
  target_timeline_months INTEGER,
  risk_tolerance VARCHAR(50) CHECK (risk_tolerance IN ('low', 'medium', 'high')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_financial_profiles_user_id ON financial_profiles(user_id);

-- Capital Blueprints table
CREATE TABLE capital_blueprints (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_profile_id UUID REFERENCES financial_profiles(id) ON DELETE SET NULL,
  blueprint_data JSONB NOT NULL,
  summary TEXT,
  target_amount DECIMAL(12, 2),
  timeline_months INTEGER,
  confidence_score DECIMAL(3, 2),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'completed', 'archived')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_capital_blueprints_user_id ON capital_blueprints(user_id);
CREATE INDEX idx_capital_blueprints_status ON capital_blueprints(status);

-- Income Plans table
CREATE TABLE income_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_type VARCHAR(100),
  current_income DECIMAL(12, 2),
  target_income DECIMAL(12, 2),
  timeline_months INTEGER,
  strategy_data JSONB,
  action_steps JSONB,
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'in_progress', 'completed', 'paused')),
  progress_percentage INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_income_plans_user_id ON income_plans(user_id);

-- Side Hustles table
CREATE TABLE side_hustles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  income_plan_id UUID REFERENCES income_plans(id) ON DELETE SET NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  estimated_monthly_income DECIMAL(12, 2),
  actual_monthly_income DECIMAL(12, 2),
  time_commitment_hours INTEGER,
  startup_cost DECIMAL(12, 2),
  status VARCHAR(50) DEFAULT 'idea' CHECK (status IN ('idea', 'planning', 'active', 'paused', 'discontinued')),
  started_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_side_hustles_user_id ON side_hustles(user_id);
CREATE INDEX idx_side_hustles_status ON side_hustles(status);

-- Mortgage Readiness Reports table
CREATE TABLE mortgage_readiness_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  financial_profile_id UUID REFERENCES financial_profiles(id) ON DELETE SET NULL,
  readiness_score INTEGER,
  max_borrowing_capacity DECIMAL(12, 2),
  recommended_deposit DECIMAL(12, 2),
  estimated_monthly_payment DECIMAL(12, 2),
  affordability_ratio DECIMAL(5, 2),
  gaps_identified JSONB,
  improvement_actions JSONB,
  timeline_to_ready_months INTEGER,
  report_data JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_mortgage_readiness_user_id ON mortgage_readiness_reports(user_id);

-- BTL (Buy-to-Let) Strategies table
CREATE TABLE btl_strategies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  strategy_name VARCHAR(255),
  target_location VARCHAR(255),
  property_type VARCHAR(100),
  purchase_price DECIMAL(12, 2),
  deposit_amount DECIMAL(12, 2),
  estimated_rental_yield DECIMAL(5, 2),
  monthly_rental_income DECIMAL(12, 2),
  monthly_costs DECIMAL(12, 2),
  net_cash_flow DECIMAL(12, 2),
  roi_percentage DECIMAL(5, 2),
  strategy_data JSONB,
  risks JSONB,
  status VARCHAR(50) DEFAULT 'planning' CHECK (status IN ('planning', 'ready', 'executing', 'completed')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_btl_strategies_user_id ON btl_strategies(user_id);

-- JV (Joint Venture) Profiles table
CREATE TABLE jv_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  profile_name VARCHAR(255),
  bio TEXT,
  experience_level VARCHAR(50) CHECK (experience_level IN ('beginner', 'intermediate', 'experienced', 'expert')),
  capital_available DECIMAL(12, 2),
  time_available_hours INTEGER,
  skills JSONB,
  preferences JSONB,
  location VARCHAR(255),
  seeking_roles JSONB,
  offering_roles JSONB,
  is_active BOOLEAN DEFAULT true,
  compatibility_data JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jv_profiles_user_id ON jv_profiles(user_id);
CREATE INDEX idx_jv_profiles_is_active ON jv_profiles(is_active);

-- JV Teams table
CREATE TABLE jv_teams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  max_members INTEGER DEFAULT 4,
  status VARCHAR(50) DEFAULT 'forming' CHECK (status IN ('forming', 'active', 'paused', 'dissolved')),
  total_capital_pooled DECIMAL(12, 2) DEFAULT 0,
  team_agreement JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jv_teams_created_by ON jv_teams(created_by);
CREATE INDEX idx_jv_teams_status ON jv_teams(status);

-- JV Team Members table
CREATE TABLE jv_team_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_id UUID NOT NULL REFERENCES jv_teams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  jv_profile_id UUID REFERENCES jv_profiles(id) ON DELETE SET NULL,
  role VARCHAR(100),
  capital_contribution DECIMAL(12, 2) DEFAULT 0,
  equity_percentage DECIMAL(5, 2),
  responsibilities JSONB,
  voting_power INTEGER DEFAULT 1,
  status VARCHAR(50) DEFAULT 'invited' CHECK (status IN ('invited', 'active', 'left', 'removed')),
  joined_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(team_id, user_id)
);

CREATE INDEX idx_jv_team_members_team_id ON jv_team_members(team_id);
CREATE INDEX idx_jv_team_members_user_id ON jv_team_members(user_id);

-- JV Contracts table
CREATE TABLE jv_contracts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_id UUID NOT NULL REFERENCES jv_teams(id) ON DELETE CASCADE,
  contract_type VARCHAR(100),
  contract_data JSONB NOT NULL,
  pdf_url VARCHAR(500),
  status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft', 'pending_signatures', 'signed', 'active', 'terminated')),
  generated_by VARCHAR(50) DEFAULT 'AI',
  generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  signed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jv_contracts_team_id ON jv_contracts(team_id);

-- JV Projects table
CREATE TABLE jv_projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_id UUID NOT NULL REFERENCES jv_teams(id) ON DELETE CASCADE,
  project_name VARCHAR(255) NOT NULL,
  description TEXT,
  project_type VARCHAR(100),
  phase VARCHAR(50) DEFAULT 'planning' CHECK (phase IN ('planning', 'sourcing', 'financing', 'executing', 'completed', 'exited')),
  total_budget DECIMAL(12, 2),
  capital_deployed DECIMAL(12, 2) DEFAULT 0,
  target_roi_percentage DECIMAL(5, 2),
  actual_roi_percentage DECIMAL(5, 2),
  start_date DATE,
  target_completion_date DATE,
  actual_completion_date DATE,
  milestones JSONB,
  budget_tracking JSONB,
  roi_forecast JSONB,
  risks JSONB,
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'on_hold', 'completed', 'canceled')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jv_projects_team_id ON jv_projects(team_id);
CREATE INDEX idx_jv_projects_phase ON jv_projects(phase);

-- Deals table
CREATE TABLE deals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  team_id UUID REFERENCES jv_teams(id) ON DELETE SET NULL,
  deal_name VARCHAR(255) NOT NULL,
  property_address TEXT,
  property_type VARCHAR(100),
  purchase_price DECIMAL(12, 2),
  deposit_required DECIMAL(12, 2),
  estimated_refurb_cost DECIMAL(12, 2),
  estimated_value_post_refurb DECIMAL(12, 2),
  estimated_rental_income DECIMAL(12, 2),
  deal_analysis JSONB,
  sourcing_method VARCHAR(100),
  status VARCHAR(50) DEFAULT 'analyzing' CHECK (status IN ('analyzing', 'pursuing', 'offer_made', 'accepted', 'completed', 'lost', 'abandoned')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_deals_user_id ON deals(user_id);
CREATE INDEX idx_deals_team_id ON deals(team_id);
CREATE INDEX idx_deals_status ON deals(status);

-- Simulations table
CREATE TABLE simulations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  simulation_type VARCHAR(100) NOT NULL,
  input_data JSONB NOT NULL,
  output_data JSONB,
  status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed')),
  job_id VARCHAR(255),
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP
);

CREATE INDEX idx_simulations_user_id ON simulations(user_id);
CREATE INDEX idx_simulations_status ON simulations(status);
CREATE INDEX idx_simulations_job_id ON simulations(job_id);

-- Portfolio Models table
CREATE TABLE portfolio_models (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  model_name VARCHAR(255),
  current_portfolio_value DECIMAL(12, 2),
  target_portfolio_value DECIMAL(12, 2),
  number_of_properties INTEGER,
  total_equity DECIMAL(12, 2),
  total_debt DECIMAL(12, 2),
  monthly_cash_flow DECIMAL(12, 2),
  portfolio_data JSONB,
  scaling_strategy JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_portfolio_models_user_id ON portfolio_models(user_id);

-- Documents table
CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  team_id UUID REFERENCES jv_teams(id) ON DELETE SET NULL,
  document_name VARCHAR(255) NOT NULL,
  document_type VARCHAR(100),
  file_path VARCHAR(500) NOT NULL,
  file_size INTEGER,
  mime_type VARCHAR(100),
  is_encrypted BOOLEAN DEFAULT true,
  encryption_key VARCHAR(255),
  access_level VARCHAR(50) DEFAULT 'private' CHECK (access_level IN ('private', 'team', 'public')),
  metadata JSONB,
  uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_documents_team_id ON documents(team_id);
CREATE INDEX idx_documents_document_type ON documents(document_type);

-- Partners table
CREATE TABLE partners (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner_type VARCHAR(100),
  company_name VARCHAR(255),
  contact_name VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(50),
  location VARCHAR(255),
  service_area TEXT,
  specializations JSONB,
  bio TEXT,
  website VARCHAR(500),
  is_verified BOOLEAN DEFAULT false,
  rating DECIMAL(2, 1),
  total_referrals INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_partners_user_id ON partners(user_id);
CREATE INDEX idx_partners_partner_type ON partners(partner_type);
CREATE INDEX idx_partners_location ON partners(location);

-- Referrals table
CREATE TABLE referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  partner_id UUID REFERENCES partners(id) ON DELETE SET NULL,
  referred_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  referral_code VARCHAR(100) UNIQUE,
  status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'converted', 'inactive')),
  commission_amount DECIMAL(12, 2),
  commission_paid BOOLEAN DEFAULT false,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_referrals_referrer_user_id ON referrals(referrer_user_id);
CREATE INDEX idx_referrals_partner_id ON referrals(partner_id);
CREATE INDEX idx_referrals_referral_code ON referrals(referral_code);

-- Notifications table
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  notification_type VARCHAR(100),
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(500),
  is_read BOOLEAN DEFAULT false,
  priority VARCHAR(50) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);

-- Acceleration Scores table
CREATE TABLE acceleration_scores (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  overall_score INTEGER,
  savings_score INTEGER,
  income_score INTEGER,
  credit_score INTEGER,
  knowledge_score INTEGER,
  execution_score INTEGER,
  score_breakdown JSONB,
  recommendations JSONB,
  calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_acceleration_scores_user_id ON acceleration_scores(user_id);

-- Audit Logs table
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(255) NOT NULL,
  entity_type VARCHAR(100),
  entity_id UUID,
  changes JSONB,
  ip_address VARCHAR(45),
  user_agent TEXT,
  status VARCHAR(50),
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity_type ON audit_logs(entity_type);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

-- Background Jobs table
CREATE TABLE background_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_type VARCHAR(100) NOT NULL,
  job_data JSONB,
  status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed')),
  priority INTEGER DEFAULT 0,
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  result JSONB,
  error TEXT,
  scheduled_for TIMESTAMP,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_background_jobs_status ON background_jobs(status);
CREATE INDEX idx_background_jobs_scheduled_for ON background_jobs(scheduled_for);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_financial_profiles_updated_at BEFORE UPDATE ON financial_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_capital_blueprints_updated_at BEFORE UPDATE ON capital_blueprints FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_income_plans_updated_at BEFORE UPDATE ON income_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_side_hustles_updated_at BEFORE UPDATE ON side_hustles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mortgage_readiness_reports_updated_at BEFORE UPDATE ON mortgage_readiness_reports FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_btl_strategies_updated_at BEFORE UPDATE ON btl_strategies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jv_profiles_updated_at BEFORE UPDATE ON jv_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jv_teams_updated_at BEFORE UPDATE ON jv_teams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jv_team_members_updated_at BEFORE UPDATE ON jv_team_members FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jv_contracts_updated_at BEFORE UPDATE ON jv_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jv_projects_updated_at BEFORE UPDATE ON jv_projects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_deals_updated_at BEFORE UPDATE ON deals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_portfolio_models_updated_at BEFORE UPDATE ON portfolio_models FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_partners_updated_at BEFORE UPDATE ON partners FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_referrals_updated_at BEFORE UPDATE ON referrals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
