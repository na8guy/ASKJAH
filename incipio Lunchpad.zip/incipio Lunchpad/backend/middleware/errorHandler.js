const { logAudit } = require('../utils/auditLogger');

const errorHandler = (err, req, res, next) => {
  // Log error
  console.error('Error:', {
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    user: req.user?.id
  });

  // Log to audit if user context available
  if (req.user) {
    logAudit({
      userId: req.user.id,
      action: 'ERROR',
      entityType: 'system',
      status: 'failed',
      errorMessage: err.message,
      ipAddress: req.ip
    }).catch(console.error);
  }

  // Determine status code
  const statusCode = err.statusCode || err.status || 500;

  // Don't leak error details in production
  const message = process.env.NODE_ENV === 'production' && statusCode === 500
    ? 'Internal server error'
    : err.message;

  // Send response
  res.status(statusCode).json({
    error: message,
    ...(process.env.NODE_ENV === 'development' && {
      stack: err.stack,
      details: err.details
    })
  });
};

// 404 handler
const notFoundHandler = (req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
};

module.exports = {
  errorHandler,
  notFoundHandler
};
