import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Layout from '../components/Layout';
import toast from 'react-hot-toast';
import { Users, Plus } from 'lucide-react';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const JVHub = () => {
  const [teams, setTeams] = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [profileRes, teamsRes] = await Promise.all([
        axios.get(`${API_URL}/jv/profile`),
        axios.get(`${API_URL}/jv/teams`)
      ]);
      setProfile(profileRes.data);
      setTeams(teamsRes.data);
    } catch (error) {
      toast.error('Failed to load JV data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="loading-spinner">Loading JV Hub...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h1 style={{ fontSize: '32px', fontWeight: 'bold' }}>
            JV Hub
          </h1>
          <button className="btn btn-primary">
            <Plus size={20} style={{ marginRight: '8px' }} />
            Create Team
          </button>
        </div>

        {!profile && (
          <div className="card" style={{ marginBottom: '24px' }}>
            <h3 style={{ marginBottom: '12px' }}>Create Your JV Profile</h3>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '16px' }}>
              Set up your JV profile to get matched with compatible partners
            </p>
            <button className="btn btn-primary">Create Profile</button>
          </div>
        )}

        <div className="card">
          <h2 className="card-title">My Teams</h2>
          
          {teams.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-secondary)' }}>
              <Users size={48} style={{ margin: '0 auto 16px', opacity: 0.5 }} />
              <p>You haven't joined any teams yet</p>
            </div>
          ) : (
            <div style={{ marginTop: '16px' }}>
              {teams.map((team) => (
                <Link
                  key={team.id}
                  to={`/jv/team/${team.id}`}
                  style={{ textDecoration: 'none', color: 'inherit' }}
                >
                  <div 
                    className="card"
                    style={{
                      marginBottom: '12px',
                      cursor: 'pointer',
                      transition: 'transform 0.2s',
                      ':hover': { transform: 'translateY(-2px)' }
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '4px' }}>
                          {team.name}
                        </h3>
                        <p style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
                          {team.member_count} members • {team.status}
                        </p>
                      </div>
                      <span className={`badge badge-${team.status === 'active' ? 'pro' : 'free'}`}>
                        {team.status}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default JVHub;
