const express = require('express');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { aiLimiter } = require('../middleware/rateLimiter');
const claudeService = require('../services/claudeService');
const { addJob } = require('../workers/queue');

const router = express.Router();

// Generate Capital Blueprint
router.post('/capital-blueprint', authenticateToken, requireRole('PRO', 'ACCELERATOR', 'ADMIN'), aiLimiter, async (req, res) => {
  try {
    const { financialData } = req.body;
    const result = await claudeService.generateCapitalBlueprint(req.user.id, financialData);
    res.json(result);
  } catch (error) {
    console.error('Capital blueprint error:', error);
    res.status(500).json({ error: 'Failed to generate capital blueprint' });
  }
});

// Mortgage Readiness Analysis
router.post('/mortgage-readiness', authenticateToken, requireRole('PRO', 'ACCELERATOR', 'ADMIN'), aiLimiter, async (req, res) => {
  try {
    const { financialData } = req.body;
    const result = await claudeService.runMortgageReadiness(req.user.id, financialData);
    res.json(result);
  } catch (error) {
    console.error('Mortgage readiness error:', error);
    res.status(500).json({ error: 'Failed to analyze mortgage readiness' });
  }
});

// Income Acceleration Analysis
router.post('/income-acceleration', authenticateToken, requireRole('PRO', 'ACCELERATOR', 'ADMIN'), aiLimiter, async (req, res) => {
  try {
    const { incomeData } = req.body;
    const result = await claudeService.runIncomeAccelerationAnalysis(req.user.id, incomeData);
    res.json(result);
  } catch (error) {
    console.error('Income acceleration error:', error);
    res.status(500).json({ error: 'Failed to analyze income acceleration' });
  }
});

// BTL Strategy Model
router.post('/btl-strategy', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), aiLimiter, async (req, res) => {
  try {
    const { propertyData } = req.body;
    const result = await claudeService.runBTLStrategyModel(req.user.id, propertyData);
    res.json(result);
  } catch (error) {
    console.error('BTL strategy error:', error);
    res.status(500).json({ error: 'Failed to generate BTL strategy' });
  }
});

// JV Matching (background job for heavy computation)
router.post('/jv-matching', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const { profileData, filters } = req.body;
    
    // Queue the job for background processing
    const job = await addJob('jv-matching', {
      userId: req.user.id,
      profileData,
      filters
    });

    res.json({
      jobId: job.id,
      status: 'queued',
      message: 'JV matching queued for processing'
    });
  } catch (error) {
    console.error('JV matching error:', error);
    res.status(500).json({ error: 'Failed to queue JV matching' });
  }
});

// Check job status
router.get('/job-status/:jobId', authenticateToken, async (req, res) => {
  try {
    const { getJobStatus } = require('../workers/queue');
    const status = await getJobStatus(req.params.jobId);
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get job status' });
  }
});

// Portfolio Scaling Simulation (background job)
router.post('/portfolio-simulation', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), async (req, res) => {
  try {
    const { portfolioData, scalingParameters } = req.body;
    
    const job = await addJob('portfolio-simulation', {
      userId: req.user.id,
      portfolioData,
      scalingParameters
    });

    res.json({
      jobId: job.id,
      status: 'queued',
      message: 'Portfolio simulation queued'
    });
  } catch (error) {
    console.error('Portfolio simulation error:', error);
    res.status(500).json({ error: 'Failed to queue portfolio simulation' });
  }
});

// Deal Analysis
router.post('/deal-analysis', authenticateToken, requireRole('ACCELERATOR', 'ADMIN'), aiLimiter, async (req, res) => {
  try {
    const { dealData } = req.body;
    
    const systemPrompt = `You are a UK property deal analyzer. Analyze this deal comprehensively.

Return ONLY valid JSON:
{
  "summary": "Deal overview",
  "metrics": {
    "purchasePrice": number,
    "estimatedValue": number,
    "potentialProfit": number,
    "roi": number,
    "rentalYield": number
  },
  "projections": {},
  "risks": ["risk1"],
  "action_steps": [],
  "confidence_score": number
}`;

    const userMessage = `Deal Details: ${JSON.stringify(dealData)}`;
    const response = await claudeService.callClaude(systemPrompt, userMessage);
    const result = JSON.parse(response);

    res.json(result);
  } catch (error) {
    console.error('Deal analysis error:', error);
    res.status(500).json({ error: 'Failed to analyze deal' });
  }
});

module.exports = router;
