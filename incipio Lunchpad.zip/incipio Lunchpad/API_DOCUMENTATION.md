# Incipio Launchpad - API Documentation

Base URL: `https://your-api.onrender.com/api`

## Authentication

All authenticated endpoints require a Bearer token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## Endpoints

### Authentication

#### POST `/auth/signup`
Create a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securepassword123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:**
```json
{
  "token": "jwt-token-here",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "FREE"
  }
}
```

#### POST `/auth/login`
Login to existing account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Response:** Same as signup

#### POST `/auth/refresh`
Refresh JWT token.

**Request Body:**
```json
{
  "token": "current-jwt-token"
}
```

---

### Payments (Stripe)

#### POST `/payments/create-checkout`
Create Stripe checkout session.

**Auth Required:** Yes  
**Min Role:** FREE

**Request Body:**
```json
{
  "planType": "PRO" // or "ACCELERATOR"
}
```

**Response:**
```json
{
  "sessionId": "stripe-session-id",
  "url": "https://checkout.stripe.com/..."
}
```

#### POST `/payments/create-portal-session`
Create customer portal session.

**Auth Required:** Yes

**Response:**
```json
{
  "url": "https://billing.stripe.com/..."
}
```

#### POST `/payments/webhook`
Stripe webhook endpoint (called by Stripe, not directly).

---

### Financial Profile

#### GET `/financial/profile`
Get user's financial profile.

**Auth Required:** Yes

**Response:**
```json
{
  "id": "uuid",
  "user_id": "uuid",
  "annual_income": 50000,
  "monthly_expenses": 2000,
  "current_savings": 10000,
  "monthly_savings_target": 500,
  "debt_total": 0,
  "credit_score": 750,
  "employment_status": "Employed Full-Time",
  "employment_years": 5,
  "age": 30,
  "dependents": 0,
  "target_deposit": 50000,
  "target_timeline_months": 24,
  "risk_tolerance": "medium"
}
```

#### POST `/financial/profile`
Create or update financial profile.

**Auth Required:** Yes

**Request Body:** Same fields as response above (excluding id, user_id)

---

### AI Services

#### POST `/ai/capital-blueprint`
Generate AI-powered capital blueprint.

**Auth Required:** Yes  
**Min Role:** PRO

**Request Body:**
```json
{
  "financialData": {
    "annualIncome": 50000,
    "monthlyExpenses": 2000,
    "currentSavings": 10000,
    "targetDeposit": 50000,
    "debtTotal": 0,
    "creditScore": 750
  }
}
```

**Response:**
```json
{
  "summary": "Strategic plan overview...",
  "metrics": {
    "currentSavings": 10000,
    "targetDeposit": 50000,
    "monthlyRequired": 1667,
    "timelineMonths": 24
  },
  "projections": {
    "month6": 15000,
    "month12": 25000,
    "month18": 37500,
    "month24": 50000
  },
  "risks": ["Market volatility", "Income disruption"],
  "action_steps": [
    {
      "step": "Open high-yield savings account",
      "priority": "high",
      "timeline": "immediate"
    }
  ],
  "confidence_score": 0.85
}
```

#### POST `/ai/mortgage-readiness`
Analyze mortgage readiness.

**Auth Required:** Yes  
**Min Role:** PRO

**Request Body:**
```json
{
  "financialData": {
    "annualIncome": 50000,
    "monthlyExpenses": 2000,
    "currentSavings": 10000,
    "debtTotal": 0,
    "creditScore": 750,
    "employmentStatus": "Employed Full-Time",
    "employmentYears": 5
  }
}
```

**Response:**
```json
{
  "summary": "Readiness assessment...",
  "metrics": {
    "readinessScore": 75,
    "maxBorrowingCapacity": 225000,
    "recommendedDeposit": 25000,
    "estimatedMonthlyPayment": 1100,
    "affordabilityRatio": 0.26
  },
  "projections": {},
  "risks": [],
  "action_steps": [],
  "confidence_score": 0.82
}
```

#### POST `/ai/income-acceleration`
Generate income acceleration plan.

**Auth Required:** Yes  
**Min Role:** PRO

#### POST `/ai/btl-strategy`
Generate BTL strategy analysis.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

#### POST `/ai/jv-matching`
Queue AI JV partner matching (background job).

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

**Response:**
```json
{
  "jobId": "uuid",
  "status": "queued",
  "message": "JV matching queued for processing"
}
```

#### GET `/ai/job-status/:jobId`
Check background job status.

**Auth Required:** Yes

**Response:**
```json
{
  "id": "uuid",
  "job_type": "jv-matching",
  "status": "completed",
  "result": { /* job result data */ },
  "created_at": "2024-01-01T00:00:00Z",
  "completed_at": "2024-01-01T00:01:30Z"
}
```

---

### JV (Joint Venture) Engine

#### POST `/jv/profile`
Create JV profile.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

**Request Body:**
```json
{
  "profileName": "Experienced Investor",
  "bio": "10 years in property...",
  "experienceLevel": "experienced",
  "capitalAvailable": 100000,
  "timeAvailableHours": 20,
  "skills": ["deal sourcing", "refurbishment"],
  "preferences": {},
  "location": "London",
  "seekingRoles": ["capital partner"],
  "offeringRoles": ["project management"]
}
```

#### GET `/jv/profile`
Get my JV profile.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

#### GET `/jv/profiles`
Get all active JV profiles (for matching).

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

#### POST `/jv/find-matches`
AI-powered JV partner matching.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

**Response:**
```json
{
  "summary": "Found 5 compatible matches",
  "matches": [
    {
      "candidateId": "uuid",
      "compatibilityScore": 87,
      "strengths": ["Complementary skills", "Similar capital"],
      "synergies": ["Both seeking BTL deals"],
      "considerations": ["Different locations"]
    }
  ]
}
```

#### POST `/jv/team`
Create JV team.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

**Request Body:**
```json
{
  "name": "London BTL Investors",
  "description": "Focus on London BTL opportunities",
  "invitedUserIds": ["uuid1", "uuid2"]
}
```

#### GET `/jv/teams`
Get my teams.

**Auth Required:** Yes

#### GET `/jv/team/:teamId`
Get team details.

**Auth Required:** Yes

#### POST `/jv/team/:teamId/accept`
Accept team invitation.

**Auth Required:** Yes

#### POST `/jv/project`
Create JV project.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

#### GET `/jv/team/:teamId/projects`
Get team projects.

**Auth Required:** Yes

#### POST `/jv/team/:teamId/generate-contract`
Generate AI JV contract.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

---

### Deals

#### POST `/deals`
Create deal.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

**Request Body:**
```json
{
  "dealName": "3-bed terrace refurb",
  "propertyAddress": "123 Main St, London",
  "propertyType": "Terrace",
  "purchasePrice": 250000,
  "depositRequired": 50000,
  "estimatedRefurbCost": 30000,
  "estimatedValuePostRefurb": 320000,
  "estimatedRentalIncome": 1500,
  "sourcingMethod": "Estate Agent",
  "teamId": "uuid-optional"
}
```

#### GET `/deals`
Get my deals.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

#### PUT `/deals/:id/status`
Update deal status.

**Auth Required:** Yes  
**Min Role:** ACCELERATOR

---

### Documents

#### POST `/documents/upload`
Upload document.

**Auth Required:** Yes

**Request:** multipart/form-data
- `document` (file)
- `documentType` (string)
- `teamId` (optional)
- `accessLevel` ("private" | "team" | "public")

**Response:**
```json
{
  "id": "uuid",
  "document_name": "bank_statement.pdf",
  "file_path": "/uploads/...",
  "file_size": 1024000,
  "created_at": "2024-01-01T00:00:00Z"
}
```

#### GET `/documents`
Get my documents.

**Auth Required:** Yes

---

### Partners

#### GET `/partners`
Get partner directory.

**Auth Required:** Yes

**Query Parameters:**
- `partnerType` - Filter by type
- `location` - Filter by location

#### POST `/partners`
Create partner profile.

**Auth Required:** Yes  
**Min Role:** PARTNER

---

### Notifications

#### GET `/notifications`
Get notifications.

**Auth Required:** Yes

**Response:**
```json
[
  {
    "id": "uuid",
    "notification_type": "savings_reminder",
    "title": "Weekly Savings Check-In",
    "message": "Have you hit your target?",
    "link": "/dashboard/savings",
    "is_read": false,
    "priority": "normal",
    "created_at": "2024-01-01T00:00:00Z"
  }
]
```

#### PUT `/notifications/:id/read`
Mark notification as read.

**Auth Required:** Yes

---

## Error Responses

All endpoints may return error responses:

```json
{
  "error": "Error message here"
}
```

Common status codes:
- `400` - Bad Request (validation error)
- `401` - Unauthorized (not authenticated)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found
- `429` - Too Many Requests (rate limited)
- `500` - Internal Server Error

## Rate Limits

- General API: 100 requests per 15 minutes
- Authentication: 5 attempts per 15 minutes
- AI endpoints: 10 requests per minute

## Role Hierarchy

- `FREE` - Basic access
- `PRO` - AI tools access
- `ACCELERATOR` - Full JV engine + advanced tools
- `ADMIN` - Full platform access
- `PARTNER` - Partner directory access
