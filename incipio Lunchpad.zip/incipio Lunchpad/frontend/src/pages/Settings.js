import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const Settings = () => {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px' }}>
          Settings
        </h1>

        <div className="card" style={{ marginBottom: '24px' }}>
          <h2 className="card-title">Account</h2>
          <div style={{ marginTop: '16px' }}>
            <div style={{ marginBottom: '12px' }}>
              <strong>Email:</strong> {user?.email}
            </div>
            <div style={{ marginBottom: '12px' }}>
              <strong>Name:</strong> {user?.firstName} {user?.lastName}
            </div>
            <div>
              <strong>Plan:</strong>{' '}
              <span className={`badge badge-${user?.role.toLowerCase()}`}>
                {user?.role}
              </span>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="card-title">Preferences</h2>
          <div style={{ marginTop: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <strong>Theme</strong>
                <p style={{ fontSize: '14px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  Current: {theme === 'light' ? 'Light Mode' : 'Dark Mode'}
                </p>
              </div>
              <button onClick={toggleTheme} className="btn btn-outline">
                Toggle Theme
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
