const express = require('express');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { query } = require('../config/database');

const router = express.Router();

// Create Partner Profile
router.post('/', authenticateToken, requireRole('PARTNER', 'ADMIN'), async (req, res) => {
  try {
    const {
      partnerType, companyName, contactName, email, phone,
      location, serviceArea, specializations, bio, website
    } = req.body;

    const result = await query(
      `INSERT INTO partners (
        user_id, partner_type, company_name, contact_name, email, phone,
        location, service_area, specializations, bio, website
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING *`,
      [req.user.id, partnerType, companyName, contactName, email, phone,
       location, serviceArea, JSON.stringify(specializations), bio, website]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Partner creation error:', error);
    res.status(500).json({ error: 'Failed to create partner profile' });
  }
});

// Get All Partners
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { partnerType, location } = req.query;
    let queryText = 'SELECT * FROM partners WHERE is_verified = true';
    const params = [];

    if (partnerType) {
      params.push(partnerType);
      queryText += ` AND partner_type = $${params.length}`;
    }

    if (location) {
      params.push(`%${location}%`);
      queryText += ` AND location ILIKE $${params.length}`;
    }

    queryText += ' ORDER BY rating DESC, total_referrals DESC';

    const result = await query(queryText, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get partners' });
  }
});

module.exports = router;
