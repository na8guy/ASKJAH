import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Layout from '../components/Layout';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const JVTeam = () => {
  const { teamId } = useParams();
  const [team, setTeam] = useState(null);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTeamDetails();
  }, [teamId]);

  const fetchTeamDetails = async () => {
    try {
      const response = await axios.get(`${API_URL}/jv/team/${teamId}`);
      setTeam(response.data.team);
      setMembers(response.data.members);
    } catch (error) {
      toast.error('Failed to load team details');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="loading-spinner">Loading team...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '8px' }}>
          {team?.name}
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '24px' }}>
          {team?.description}
        </p>

        <div className="card">
          <h2 className="card-title">Team Members</h2>
          <table className="table" style={{ marginTop: '16px' }}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Status</th>
                <th>Capital</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member) => (
                <tr key={member.id}>
                  <td>{member.first_name} {member.last_name}</td>
                  <td>{member.role || 'Member'}</td>
                  <td>
                    <span className={`badge badge-${member.status === 'active' ? 'pro' : 'free'}`}>
                      {member.status}
                    </span>
                  </td>
                  <td>£{member.capital_contribution?.toLocaleString() || '0'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};

export default JVTeam;
